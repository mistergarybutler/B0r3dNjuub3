// Test_UnitTests_EXE.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"
#include "..\CommonFiles\UtilityFunctions\FileUtilities.h"
#include "..\CommonFiles\UtilityFunctions\ProcessUtilities.h"
#include "..\CommonFiles\UtilityFunctions\vxUtilities.h"
#include "..\CommonFiles\UtilityFunctions\WMICovertStorage.h"
#include "Test_UnitTests_EXE.h"

//Unit test definitions
//NOTE: Some unit tests require elevated privileges in order to be successful. Run Visual Studio as Administrator to perform these tests
//#define TEST_ALL //uncomment this to complete all tests. WARNING: May include non-temporary system changes

/***General Unit Tests***/
#define TEST_ARGPARSING

/***VXUtilities Unit Tests***/
#define TEST_VXUTIL_STRINGOBFUSCATION

/***ProcessUtilities Unit Tests***/
#define TEST_PROCUTIL_ODSDISPLAYPROCTHDINFO
#define TEST_PROCUTIL_GETPROCESSINTEGRITYLEVEL

/***Misc Unit Tests***/
#define TEST_MISC_WMICOVERTSTORAGE

//The main function is to test the ability to parse arguments from the commandline
int _tmain(int argc, _TCHAR* argv[])
{
	//UNIT TEST: Command line EXE argument parsing functionality
#if defined(TEST_ARGPARSING) || defined(TEST_ALL)
	ODSDisplayInformation(TEXT("***** COMMAND LINE INVOCATION *****\n"));
	ODSDisplayInformation(TEXT("[*] Number of Arguments: %d\n"), argc);
	for (int i = 0; i < argc; i++) {
		ODSDisplayInformation(TEXT("[*] Argument #%d: %s\n"), i, argv[i]);
	}
	ODSDisplayInformation(TEXT("***********************************\n"));

	//Basic argument validity parsing.
	int argcExpected = 2; //How many arguments are you expecting?
	if (argc != argcExpected) {
		ODSDisplayError(TEXT("Failed to validate arguments. USAGE: [Exename] ..."));
		return -1;
	}
	//END OF TEST_ARGPARSING UNIT TEST

	//Run VXUtilities Unit Tests
	RunvxUtilitiesUnitTests();

	//Run ProcessUtilities Unit Tests
	RunProcessUtilitiesUnitTests();

	//Run Misc Unit Tests
	RunMiscUnitTests();
#endif



    return 0;
}
//IMPORTANT: If the unit test modifies the underlying system (ie adds a certificate) include 
//instructions on how to undo or snapshot VM prior to test.
void RunvxUtilitiesUnitTests() {
	//UNIT TEST: Test string obfuscation functionality
	//VALIDATION: Use Sysinternals Strings.exe to look for the specified value
#if defined(TEST_VXUTIL_STRINGOBFUSCATION) || defined(TEST_ALL)
	ODSDisplayInformation(TEXT("***** START UNIT TEST: XorS() *****\n"));
	LPCSTR ANSIEncryptedString = XORSTR("Search for this ANSI string in Sysinternals\n");
	//XorS(ANSIEncryptedString, "Search for this ANSI string in Sysinternals\n");
	OutputDebugStringA(ANSIEncryptedString);
	LPCWSTR UNICODEEncryptedString = XORWSTR(L"Search for this UNICODE string in Sysinternals\n");
	//XorSW(UNICODEEncryptedString, L"Search for this UNICODE string in Sysinternals\n");
	OutputDebugStringW(UNICODEEncryptedString);
	ODSDisplayInformation(TEXT("***** END UNIT TEST: XorS() *****\n"));
#endif
}

void RunProcessUtilitiesUnitTests() {
	//UNIT TEST: Display the process and thread information in the debug viewer
	//VALIDATION: Visually check to ensure the information presented is correct for the situation
	//NOTE: Running this test also validates: GetParentPID(), IsElevated()
#if defined(TEST_PROCUTIL_ODSDISPLAYPROCTHDINFO) || defined(TEST_ALL)
	ODSDisplayProcThdInfo();
#endif//END OF TEST_PROCUTIL_ODSDISPLAYPROCTHDINFO UNIT TEST

	//UNIT TEST: Get the integrity level of a known high and mid process
	//NOTE: This test must be run as admin
	//The integrity level of the current process is tested by ODSDisplayProcThdInfo

#if defined(TEST_PROCUTIL_GETPROCESSINTEGRITYLEVEL) || defined(TEST_ALL)
	ODSDisplayInformation(TEXT("***** START UNIT TEST: GetProcessIntegrityLevel() *****\n"));
	
	//TODO: Spin up a known low integrity process (IE child frame) and test that
	DWORD dwMidProcPID = GetProcessByName(TEXT("explorer.exe"));
	DWORD dwHighProcPID = GetProcessByName(TEXT("lsass.exe"));
	DWORD dwSysProcPID = GetProcessByName(TEXT("csrss.exe"));

	//Get the integrity level of a known medium process explorer.exe
	DWORD dwMidProcIntegrityLvl = GetProcessIntegrityLevel(dwMidProcPID);
	DWORD dwHighProcIntegrityLvl = GetProcessIntegrityLevel(dwHighProcPID);
	DWORD dwSysProcIntegrityLvl = GetProcessIntegrityLevel(dwSysProcPID);
	DWORD dwProcIntegrityLvl = dwMidProcIntegrityLvl;
	ODSDisplayInformation(TEXT("[*] Targeting Known Medium Integrity Process explorer.exe...\n"));
	for (int i = 0; i < 3; i++) {
		switch (dwProcIntegrityLvl) {
		case 1:
			ODSDisplayInformation(TEXT("Target Process is: Low Integrity\n"));
			break;
		case 2:
			ODSDisplayInformation(TEXT("Target Process is: Medium Integrity\n"));
			break;
		case 3:
			ODSDisplayInformation(TEXT("Target Process is: High Integrity\n"));
			break;
		case 4:
			ODSDisplayInformation(TEXT("Target Process is: System Integrity\n"));
			break;
		case 5:
			ODSDisplayInformation(TEXT("Target Process is: Higher than Low Integrity (Access Denied)\n"));
			break;
		case 6:
			ODSDisplayInformation(TEXT("Target Process is: Higher than Medium Integrity (Access Denied)\n"));
			break;
		case 7:
			ODSDisplayInformation(TEXT("Target Process is: Higher than High Integrity (Access Denied)\n"));
			break;
		default:
			ODSDisplayError(TEXT("UNIT TEST FAILED: Could not get integrity level"));
		}//end of switch statement
		if (i == 0) {
			dwProcIntegrityLvl = dwHighProcIntegrityLvl;
			ODSDisplayInformation(TEXT("[*] Targeting Known High Integrity Process lsass.exe...\n"));
		}
		else if (i == 1) {
			dwProcIntegrityLvl = dwSysProcIntegrityLvl;
			ODSDisplayInformation(TEXT("[*] Targeting Known System Integrity Process csrss.exe...\n"));
		}
	}//end of for loop

	

	ODSDisplayInformation(TEXT("***** END UNIT TEST: GetProcessIntegrityLevel() *****\n"));
#endif //END OF TEST_PROCUTIL_GETPROCESSINTEGRITYLEVEL
}


void RunMiscUnitTests() {
#if defined(TEST_MISC_WMICOVERTSTORAGE) || defined(TEST_ALL)
	ODSDisplayInformation(TEXT("***** START UNIT TEST: WMI Covert Storage *****\n"));
	//UNIT TEST: Put something in covert storage 
	//Storage/delete requires elevated privs, retrieval can be done by anyone
	//Manual step: retrieve and clear it with the powershell commands:
	//Retrieve - gwmi -query "select index,message from win32_ntlog" | Sort-Object Index | select Index,Message
	//Delete - rwmi win32_ntlog

	//Create an instance of the struct
	struct WMILogInstance liWMILogger;
	liWMILogger.LOG_MUTEX = L"wmi-mx";
	liWMILogger.pSvc = NULL;
	liWMILogger.pLoc = NULL;
	liWMILogger.WMI_CLASS_NAME = L"Win32_NTLog";
	liWMILogger.message_num = 0;


	if (SetupWMILogging(&liWMILogger) != 0) {
		ODSDisplayError(TEXT("Failed to initialize WMI covert storage location"));
	}
	else {
		WriteWMILog(&liWMILogger, TEXT("This is a test of WMI Covert Storage Logger"));
		CleanupWMILogging(&liWMILogger);
	}
	ODSDisplayInformation(TEXT("***** END UNIT TEST: WMI Covert Storage *****\n"));
#endif
}
