/**
* @file Test_DynamicLibaryLoader_EXE.cpp
* @author oz
* @date 20170317
* @brief Testing project to execute a specified DLL using the various known methods of DLL injection
*
* This project is a testing utility that can inject the produced capability DLLs using a variety of known
* DLL injection mechanisms. It is included as a project for special testing cases where the source needws to
* be modifed. Any modifications that may be relevant to other projects should be re-submitted as JIRA tickets
* on the Windows Capability Template project.
*
* Projects that utilize this testing project should:
* - Have this project set as a dependency of the DLL project in the capability solution
* -- Solution Properties > Common Properties > Project Dependencies
* - Set their debugger to execute the appropriate injection method to be tested. See below for examples
* -- Project Properties > Configuration Proerties > Debugging > Command && Command Arguments
*
*/

#include "stdafx.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"
#include "Test_DynamicLibaryLoader_EXE.h"

#ifdef WIN_X86
	#ifdef _DEBUG
		#define DLL_TO_LOAD TEXT("OutputMarshal_DLL_DEBUG32.dll")
	#endif
	#ifndef _DEBUG
		#define DLL_TO_LOAD TEXT("OutputMarshal_DLL32.dll")	
	#endif
#endif
#ifdef WIN_X64
	#ifdef _DEBUG
		#define DLL_TO_LOAD TEXT("OutputMarshal_DLL_DEBUG64.dll")
	#endif
	#ifndef _DEBUG
		#define DLL_TO_LOAD TEXT("OutputMarshal_DLL64.dll")	
	#endif
#endif

//Definitions to specify the Custom DLL search order
//TRADECRAFT: Don't use backwards relative paths like this production code! It introduces a potential DLL hijacking vulnerability
//as you might be going past directories where you have control over the permissions
#define DLLSEARCHDIR1 TEXT("..\\..\\Bins")
#define DLLSEARCHDIR2 TEXT(".\\")

//Suppress the console dialog box
//#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:wmainCRTStartup")

/**
* @brief Main function for Dynamic Library Loader
*
* Function takes in arguments related to what type of injection to use to exectute a speficied DLL file.
* This can also serve as an example for how to effectively parse command line arguments.
*
* @param argc The number of arguments received from the command line invocation
* @param argv An array of the value of the arguments received from the command line invocation
*
* @return 0 on success, any other value is failure
* @warning If using this as an example of argument parsing for deployable capabilities, ensure usage messages
* are stripped in release mode.
*/
//TODO: Build a 'print usage statement' function
#define REQARGS 5 //should be the number of required swtiches x 2 + 1
#define MAX_ARG_LENGTH 4096 //set the max size an argument value can be 
int _tmain(int argc, _TCHAR* argv[])
{
	int retval = -1;

	//Argument variables
	TCHAR * DLLToInject = (TCHAR *)halloc(MAX_PATH * sizeof(TCHAR));
	TCHAR * InjectionType = (TCHAR *)halloc(MAX_ARG_LENGTH * sizeof(TCHAR));
	TCHAR * ExportToCall = (TCHAR *)halloc(MAX_ARG_LENGTH * sizeof(TCHAR));
	TCHAR * ArgsToPass = (TCHAR *)halloc(MAX_ARG_LENGTH * sizeof(TCHAR));

	for (int i = 1; i < argc; i++) {
		if (i + 1 != argc) { //Check to see if we havent finished parsing if the user left off an arg value
			if (wcscmp(argv[i], L"-d") == 0 || wcscmp(argv[i], L"--dll") == 0) {
				wcscpy_s(DLLToInject, MAX_PATH, argv[i + 1]);
				i++;
			}
			else if (wcscmp(argv[i], L"-t") == 0 || wcscmp(argv[i], L"--type") == 0) {
				wcscpy_s(InjectionType, MAX_ARG_LENGTH, argv[i + 1]);
				i++;
			}
			else if (wcscmp(argv[i], L"-e") == 0 || wcscmp(argv[i], L"--export") == 0) {
				wcscpy_s(ExportToCall, MAX_ARG_LENGTH, argv[i + 1]);
				i++;
			}
			else if (wcscmp(argv[i], L"-a") == 0 || wcscmp(argv[i], L"--args") == 0) {
				wcscpy_s(ArgsToPass, MAX_ARG_LENGTH, argv[i + 1]);
				i++;
			}
			else {
				ODSDisplayError(TEXT("[-] Invalid argument specified"));
				retval = -1;
				goto FAILURE;
			}
		}
	}//end of primary argument parser


	//Ensure required arguments have been set
	if (wcscmp(DLLToInject, L"") == 0) {
		ODSDisplayError(TEXT("Missing DLL to inject"));
		retval = -1;
		goto FAILURE;
	}


	//Do extended argument processing here if required

	//Switch on injection type
	if (wcscmp(InjectionType, L"LoadLibrary") == 0 || wcscmp(InjectionType, L"loadlibrary") == 0) {
		//Validate that exports and arguments are set
		if (wcscmp(ExportToCall, L"") == 0) {
			ODSDisplayError(TEXT("[-] Missing export to call\n"));
			retval = -1;
			goto FAILURE;
		}
		else if (wcscmp(ArgsToPass, L"") == 0) {
			ODSDisplayError(TEXT("[-] Missing arguments to pass to export\n"));
			retval = -1;
			goto FAILURE;
		}
		else {
			//Call the loadlibrary injector
			retval = InjectViaLoadLibrary(DLLToInject, ExportToCall, ArgsToPass);
		}
	}
	else {
		ODSDisplayError(TEXT("[-] Invalid Injection Type specified\n"));
		retval = -1;
		goto FAILURE;
	}

SUCCESS:
	//retval is set by the status of the injector type call
FAILURE:
	hfree((void*)DLLToInject);
	hfree((void*)InjectionType);
	hfree((void*)ExportToCall);
	hfree((void*)ArgsToPass);

	return retval;
}

/**
* @brief Inject a DLL via a LoadLibrary() Call
*
* This is not really an injection but rather a standard LoadLibrary Call from the current process. It must
* be modified to support new exported functions of the DLL it is tasked to load.
*
* USAGE EXAMPLES:
* Inject via LoadLibrary: -t LoadLibrary -d Z:\path\to\DLL.dll -e DllExportedFunction -a "\"text to echo\""
*
* @param DLLToInject Path and/or filename of DLL to inject
* @param ExportToCall The name of the DLL export which will be called
* @param ArgsToPass Single string of arguments that will be broken up and passsed to the export
*
* @return 0 on success, any other value is failure
* @see Commit f8e12e57 or earlier for previous implementation
*/
DWORD InjectViaLoadLibrary(LPWSTR DLLToInject, LPWSTR ExportToCall, LPWSTR ArgsToPass) {
	int retval = -1;

	//Load the DLL.
	HMODULE hModule = LoadLibrary(DLLToInject);
	if (hModule == NULL) {
		ODSDisplayError(TEXT("[-] Failed to get handle to DLL\n"));
		retval = -1;
		goto FAILURE;
	}

	//break up the args to pass into argc argv
	LPWSTR* argv;
	int argc;

	argv = CommandLineToArgvW(ArgsToPass, &argc);
	if (argv == NULL) {
		ODSDisplayError(TEXT("CommandLineToArgvW Failed"));
		retval = -1;
		goto FAILURE;
	}

	//Create support export types
	//This is in the form of: typedef <return value> (*INTERNALNAME)(ARG1TYPE, ARG2TYPE, ETC)
	//TOOO: Change this to add prototypes that are actually exported by the library
	typedef DWORD(*DLLEXPORT1)(LPWSTR TextToEcho); //DllExportedFunction definition

	//Get a reference to the exported function
	if (wcscmp(ExportToCall, L"DllExportedFunction") == 0) {
		DLLEXPORT1 LibraryExportedFunction = (DLLEXPORT1)GetProcAddress(hModule, "DllExportedFunction");
		
		//Call exported function from DLL
		LibraryExportedFunction(argv[0]);
	}
	else {
		ODSDisplayError(TEXT("Invaid export specified"));
		retval = -1;
		goto FAILURE;
	}
	
	retval = 0;

SUCCESS:
FAILURE:

	return retval;
}
