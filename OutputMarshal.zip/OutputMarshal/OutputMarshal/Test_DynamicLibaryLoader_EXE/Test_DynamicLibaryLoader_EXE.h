#pragma once

//Internal functions
DWORD InjectViaLoadLibrary(LPWSTR DLLToInject, LPWSTR ExportToCall, LPWSTR ArgsToPass);