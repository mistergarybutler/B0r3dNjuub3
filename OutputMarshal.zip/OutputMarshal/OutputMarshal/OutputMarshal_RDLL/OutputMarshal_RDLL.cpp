/**
* @file OutputMarshal_RDLL.cpp
* @author AUTHOR
* @date YYYYMMDD
* @brief A Windows Reflective DLL stub that processes arugments from an embedded resource
*
* This project contains the minimum amount of code required to pass off execution to the reflective library that implements
* the core functionality of the capability. Any special tradecraft required to:
* - Bypass endpoint security products specific to reflective DLL files
* - Special processing of the embedded resource such as decryption/validation
* shoud be implemented here
*/

#include "stdafx.h"
#include "OutputMarshal_LIB.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"
#include "..\CommonFiles\UtilityFunctions\ProcessUtilities.h"


#ifdef WIN_X86
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG32.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB32.lib")	
	#endif
#endif
#ifdef WIN_X64
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG64.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB64.lib")	
	#endif
#endif

/**
* @brief Export to handle processing of arguments contained in the embedded resource
* 
* This is just a shell function to do Reflective DLL specific stuff, then pass execution off to the main
* code in the static lib
* 
* @param lpParam A void parameter required by the Windows specification for threadable functions
*
* @return 0 on success, any other value is failure
*/
DWORD WINAPI RDllEntryPoint(LPVOID lpParam) {
	int retval = -1;

	//Get the commands from the resource and execute 
	retval = LibExtractCmdsFromResource(101);

SUCCESS:

FAILURE:

	return retval;
}
