// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#include "OutputMarshal_RDLL.h"
#include "..\CommonFiles\PublicReflectiveInjection\ReflectiveLoader.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"

//Only define one of the below mechanisms for calling the entry point
#define BLOCKING_ENTRY //Execution will block on the entry point until it is complete
//#define THREADED_ENTRY //Entry point will thread off allowing other execution to continue

extern "C" HINSTANCE hAppInstance;

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		#ifdef BLOCKING_ENTRY
			RDllEntryPoint(NULL);
		#endif

		#ifdef THREADED_ENTRY
			HANDLE  hThread;
			DWORD   dwThreadId;
			hThread = CreateThread(NULL,0,RDllEntryPoint,NULL,0,&dwThreadId);

			if (hThread == NULL) {
				ODSDisplayError(TEXT("RI: Error on CreateThread"));
			}
			else {
				ODSDisplayInformation(TEXT("[*] RI: Created thread with ID: %d"), dwThreadId);
			}
		#endif
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

