#pragma once

DWORD WINAPI RDllEntryPoint(LPVOID lpParam); //Threadable entry point with no parameters