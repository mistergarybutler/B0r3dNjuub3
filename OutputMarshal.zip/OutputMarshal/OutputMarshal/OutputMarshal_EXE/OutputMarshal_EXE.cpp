/**
 * @file OutputMarshal_EXE.cpp
 * @author AUTHOR
 * @date YYYYMMDD
 * @brief A standard console application stub that processes arugments from the command line or an embedded resource
 *
 * This project contains the minimum amount of code required to pass off execution to the static library that implements
 * the core functionality of the capability. Any special tradecraft required to bypass endpoint security products specific
 * to EXE files shoud be implemented here
 * 
 */
#include "stdafx.h"
#include "OutputMarshal_EXE.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"

#include "OutputMarshal_LIB.h"
#ifdef WIN_X86
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG32.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB32.lib")	
	#endif
#endif
#ifdef WIN_X64
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG64.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB64.lib")	
	#endif
#endif

//Suppress the console dialog box
#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:wmainCRTStartup")

/**
 * @brief Stub to handle EXE specific processes and argument parsing
 *
 * @param argc The number of arguments received from the command line invocation
 * @param argv An array of the value of the arguments received from the command line invocation
 *
 * @return 0 on success, any other value is failure
 */
//TODO: Modify this function as required
int _tmain(int argc, _TCHAR* argv[])
{
	int retval = -1;

#ifdef EXECUTE_WITH_ARGUMENTS
	//Call the Static Library's command parser
	if (FAILED(LibCommandParser(argc, argv))) {
		//Display usage instructions
		ODSDisplayError(TEXT("Failed to validate arguments. USAGE: [Exename] ..."));
		retval = -1;
		goto FAILURE;
	}
#endif

#ifdef EXECUTE_WITH_RESOURCE
	//Get the commands from the resource and execute 
	retval = LibExtractCmdsFromResource(RES_CONFIG_DATA);
#endif
	
SUCCESS:
	retval = 0;
FAILURE:

	return retval;
}

