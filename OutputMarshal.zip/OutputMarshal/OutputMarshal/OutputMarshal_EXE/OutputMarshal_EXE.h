/**
* @file OutputMarshal_EXE.h
* @author AUTHOR
* @date YYYYMMDD
* @brief Configuration settings for the OutputMarshal_EXE project
*
* This file contains configuration settings in the form of pre-processor directive for the 
* OutputMarshal_EXE project. They are exposed in this file to easier identification
* of the different possible confiugurations the EXE can be compiled as. For production use, desired
* configurations should be chosen and implmented as customized debug and release configurations.
*/

//Choose only one of the below execution methods
#define EXECUTE_WITH_ARGUMENTS /**< Execute with the arguments as specified from the command line*/
//#define EXECUTE_WITH_RESOURCE /**< Execute with the arguments specified in the embedded resource*/

//Execute with resource specific configuration settings
#ifdef EXECUTE_WITH_RESOURCE
	#define RES_CONFIG_DATA 101 /**< Set the configuration data to be the approrpiate embedded resource*/
#endif