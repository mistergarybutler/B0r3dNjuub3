// dllmain.cpp : Defines the entry point for the DLL application.
//BEST PRACTICE: Only include the minimum ammount of code required in dllmain.cpp unless otherwise required.
//NOTE: For the standard DLL, unless otherwise necessary, don't include any code in DLL_PROCESS_ATTACH
//Accomplish all work through exported functions

#include "stdafx.h"
#include "OutputMarshal_DLL.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

