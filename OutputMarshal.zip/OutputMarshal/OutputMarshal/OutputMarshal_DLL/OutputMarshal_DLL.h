/**
* @file OutputMarshal_DLL.h
* @author AUTHOR
* @date YYYYMMDD
* @brief Header file for OutputMarshal_DLL.cpp
*
* This file also contains configuration settings in the form of pre-processor directive for the
* OutputMarshal_DLL project. They are exposed in this file to easier identification
* of the different possible confiugurations the EXE can be compiled as. For production use, desired
* configurations should be chosen and implmented as customized debug and release configurations.
*/
#pragma once
#include <Windows.h>

/***** CONFIGURATION SETTINGS *****/
//Choose only one of the below execution methods
#define EXECUTE_WITH_ARGUMENTS /**< Execute with the arguments as specified from the command line*/
//#define EXECUTE_WITH_RESOURCE /**< Execute with the arguments specified in the embedded resource*/

//Execute with resource specific configuration settings
#ifdef EXECUTE_WITH_RESOURCE
	#define RES_CONFIG_DATA 101 /**< Set the configuration data to be the approrpiate embedded resource*/
#endif
/***** END OF CONFIGURATION SETTINGS *****/

//EXPORTED FUNCTIONS
//NOTE: Use Extern "C" for maximum compatibility with other TTPs

//TRADECRAFT: !!Change the name of these functions!!
extern "C"
{
	__declspec(dllexport) DWORD __stdcall HyperionExportedFunctionW(LPWSTR lpszCmdLine);
}
extern "C"
{
	__declspec(dllexport) DWORD __stdcall DllExportedFunction(int CertLen, LPWSTR Certificate);
}

extern "C"
{
	__declspec(dllexport) void __stdcall RundllExportW(HWND hwnd, HINSTANCE hisnt, LPWSTR lpszCmdLine, int nCmdShow);
}