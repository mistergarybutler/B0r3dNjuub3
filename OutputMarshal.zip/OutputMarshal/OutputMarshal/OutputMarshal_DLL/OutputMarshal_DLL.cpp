/**
* @file OutputMarshal_DLL.cpp
* @author AUTHOR
* @date YYYYMMDD
* @brief A Windows DLL stub that processes arugments from an exported function call, rundll32, or an embedded resource
*
* This project contains the minimum amount of code required to pass off execution to the static library that implements
* the core functionality of the capability. Any special tradecraft required to:
* - Bypass endpoint security products specific to DLL files
* - Special exports expected/required by the loading process
* shoud be implemented here
*
*/

#include "stdafx.h"
#include "OutputMarshal_DLL.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"

#include "OutputMarshal_LIB.h"
#ifdef WIN_X86
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG32.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB32.lib")	
	#endif
#endif
#ifdef WIN_X64
	#ifdef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB_DEBUG64.lib")	
	#endif
	#ifndef _DEBUG
		#pragma comment(lib,"OutputMarshal_LIB64.lib")	
	#endif
#endif

/**
* @brief Export to handle Hyperion specific processes and argument parsing
*
* @param lpszCmdLine A wide string containing the command line as sent from Hyperion
*
* @return 0 on success, any other value is failure
*/
//TRADECRAFT: Change the name of this function or call by ordinal
__declspec(dllexport) DWORD __stdcall HyperionExportedFunctionW(LPWSTR lpszCmdLine) {
	int retval = -1;

#ifdef EXECUTE_WITH_ARGUMENTS
	retval = LibCmdLineParser(lpszCmdLine);
#endif

#ifdef EXECUTE_WITH_RESOURCE
	retval = LibExtractCmdsFromResource(RES_CONFIG_DATA);
#endif 

SUCCESS:

FAILURE:

	return retval;
}

/**
* @brief Export to handle execution via a typical LoadLibrary()/Export call with arguments
*
* This is just a shell function to handle any standard DLL processing of arguments received via a 
* typical exported function call. It can directly pass arguments to the static library's entry point.
*
* @param TextToEcho A generic parameter to demonstrate how this export works, remove for production use
* @param FILL_ME_IN Once the function is modified for the purposes of the capability, list the arguments here
*
* @return 0 on success, any other value is failure
*/
//TODO: Modify this function as required
DWORD DllExportedFunction(LPWSTR TextToEcho) {
	int retval = -1;

	LibEntryPoint(TextToEcho);

SUCCESS:
	retval = 0;
FAILURE:

	return retval;
}

/**
* @brief Export to handle Rundll32 specific processes and argument parsing
*
* @param hwnd
* @param hinst
* @param lpszCmdLine A wide string containing the command line as sent from Rundll32
* @param nCmdShow
*
* @return void, as required by the Rundll32 specification
* @see https://support.microsoft.com/en-us/kb/164787
*/
//TRADECRAFT: Change the name of this function or call by ordinal
void CALLBACK RundllExportW(HWND hwnd, HINSTANCE hisnt, LPWSTR lpszCmdLine, int nCmdShow) {
#ifdef EXECUTE_WITH_ARGUMENTS
	LibCmdLineParser(lpszCmdLine);
#endif

#ifdef EXECUTE_WITH_RESOURCE
	LibExtractCmdsFromResource(RES_CONFIG_DATA);
#endif

SUCCESS:

FAILURE:

	return;
}