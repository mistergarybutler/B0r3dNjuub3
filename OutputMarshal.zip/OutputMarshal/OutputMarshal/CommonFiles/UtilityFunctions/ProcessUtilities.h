//Inlcudes
#include <Windows.h>

//**********External Functions**********
DWORD GetParentPID();

void ODSDisplayProcThdInfo();

HANDLE CheckSharedMutex(TCHAR* mutexName);

DWORD GetProcessByName(PCWSTR name);

HMODULE GetCurrentModule();

BOOL IsElevated();

DWORD GetProcessIntegrityLevel(DWORD dwPID);

LPCWSTR GetResourceAsLPCWSTR(HMODULE hDLL, int ResourceID);