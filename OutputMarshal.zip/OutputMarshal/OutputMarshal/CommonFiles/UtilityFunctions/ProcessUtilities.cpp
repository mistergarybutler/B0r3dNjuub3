//includes
#include "CoreUtilities.h"
#include "ProcessUtilities.h"
#include <Windows.h>
#include <tlhelp32.h>
#include <tchar.h>	//must be included before strsafe
#include <strsafe.h> //Required for StringCchPrintf functions
#include <Psapi.h> // Required for GetModuleFileNameEx


//Code block to support finding the handle yourself if you are a DLL
#if _MSC_VER >= 1300    // for VC 7.0
  // from ATL 7.0 sources
  #ifndef _delayimp_h
  extern "C" IMAGE_DOS_HEADER __ImageBase;
  #endif
#endif

//display the various details of the process the DLL is running inside of
void ODSDisplayProcThdInfo() {
	#define MAX_SIZE 4096
	
	//Allocate heap variables
	TCHAR * processName = (TCHAR *)halloc(MAX_PATH*sizeof(TCHAR));
	TCHAR * parentProcessName = (TCHAR *)halloc(MAX_PATH*sizeof(TCHAR));
	TCHAR * username = (TCHAR *)halloc(2048*sizeof(TCHAR));

	//Other variables
	DWORD processID;
	DWORD parentProcessID;
	DWORD threadID;
	DWORD usernameLen = 2048;

	//Get the current processID, and threadID
	processID = GetCurrentProcessId();
	threadID = GetCurrentThreadId();

	//Get the Process Name
	if(FAILED(GetModuleFileName(NULL, processName, MAX_PATH)))
			ODSDisplayError(TEXT("GetModuleFileName - Process"));

	//Get parent process details
	parentProcessID = GetParentPID();
	HANDLE hParentProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, parentProcessID);
    if (hParentProcess) {
		if(GetModuleFileNameEx(hParentProcess, NULL, parentProcessName, MAX_PATH)==0)
			ODSDisplayError(TEXT("Failed to get name of parent process"));
		
		CloseHandle(hParentProcess);
	}

	//Get the username
	if(FAILED(GetUserName(username, &usernameLen)))
			ODSDisplayError(TEXT("GetUsername"));

	//Determine if process is elevated
	bool IsProcElevated = IsElevated();

	//Determine the integrity level of process
	DWORD CurrentProcIntegrityLvl = GetProcessIntegrityLevel(0);

	//Output results to Debug
	//Note: If any of the name results are not set due to other errors, halloc will save with null terminated strings
	ODSDisplayInformation(TEXT("*****PROCESS/THREAD INFO*****\n"));
	ODSDisplayInformation(TEXT("[*] [PID] Process: [%d] %s\n"), processID, processName);
	ODSDisplayInformation(TEXT("[*] [PID] Parent Process: [%d] %s \n"), parentProcessID, parentProcessName);
	ODSDisplayInformation(TEXT("[*] Thread ID: %d\n"), threadID);
	ODSDisplayInformation(TEXT("[*] User Context: %s\n"), username);
	ODSDisplayInformation(TEXT("[*] Process is Elevated?: %s\n"), (IsProcElevated ? TEXT("True") : TEXT("False")));
	switch (CurrentProcIntegrityLvl) {
	case 1:
		ODSDisplayInformation(TEXT("Current Process is: Low Integrity\n"));
		break;
	case 2:
		ODSDisplayInformation(TEXT("Current Process is: Medium Integrity\n"));
		break;
	case 3:
		ODSDisplayInformation(TEXT("Current Process is: High Integrity\n"));
		break;
	case 4:
		ODSDisplayInformation(TEXT("Current Process is: System Integrity\n"));
		break;
	default:
		ODSDisplayError(TEXT("UNIT TEST FAILED: Could not get integrity level"));
	}
	ODSDisplayInformation(TEXT("*****PROCESS/THREAD INFO*****\n"));
	
	//Free the heap
	hfree((void*)processName);
	hfree((void*)parentProcessName);
	hfree((void*)username);
}

//Get the Parent Process ID of the caller of the function
//TRADECRAFT: This function uses CreateToolhelp32Snapshot which is heuristically bad
DWORD GetParentPID() {
    HANDLE hSnapshot;
    PROCESSENTRY32 pe32;
    DWORD ppid = 0, pid = GetCurrentProcessId();

    hSnapshot = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
    __try{
        if( hSnapshot == INVALID_HANDLE_VALUE ) __leave;

        ZeroMemory( &pe32, sizeof( pe32 ) );
        pe32.dwSize = sizeof( pe32 );
        if( !Process32First( hSnapshot, &pe32 ) ) __leave;

        do{
            if( pe32.th32ProcessID == pid ){
                ppid = pe32.th32ParentProcessID;
                break;
            }
        }while( Process32Next( hSnapshot, &pe32 ) );

    }
    __finally{
        if( hSnapshot != INVALID_HANDLE_VALUE ) CloseHandle( hSnapshot );
    }
    return ppid;
}

//This function will search for an create a named mutex file.
//Return values: NULL - failed to acquire the mutex
//              HANDLE  - it is safe to use this handle and you are the only one who has a handle to it
HANDLE CheckSharedMutex(TCHAR* mutexName) {
    HANDLE hMutex;
    hMutex = CreateMutex(NULL,  FALSE,  mutexName);  // object name
    if (hMutex == NULL) {
        ODSDisplayError(TEXT("Mutex: Unable to create handle"));
        return NULL;
    }
    else
        if (GetLastError() == ERROR_ALREADY_EXISTS
            || GetLastError() == ERROR_INVALID_HANDLE
            || GetLastError() == ERROR_ACCESS_DENIED){
			CloseHandle(hMutex);
            return NULL;    
		}
        else
            return hMutex;
}

//Get the PID of the first process that has the supplied name
DWORD GetProcessByName(PCWSTR name) {
    DWORD pid = 0;

    // Create toolhelp snapshot.
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 process;
    ZeroMemory(&process, sizeof(process));
    process.dwSize = sizeof(process);

    // Walkthrough all processes.
    if (Process32First(snapshot, &process)) {
        do {
            // Compare process.szExeFile based on format of name, i.e., trim file path
            // trim .exe if necessary, etc.
			if (_tcsicmp(process.szExeFile, name) == 0) {
               pid = process.th32ProcessID;
               break;
            }
        } 
		while (Process32Next(snapshot, &process) == TRUE);
    }

    CloseHandle(snapshot);

    if (pid != 0) {
         return pid;
    }

    // Not found
	return -1;
}

//Get a handle to the current module, useful for finding yourself in memory if you are DLL.
HMODULE GetCurrentModule() {
#if _MSC_VER < 1300    // earlier than .NET compiler (VC 6.0)
  // Here's a trick that will get you the handle of the module
  // you're running in without any a-priori knowledge:
  // http://www.dotnet247.com/247reference/msgs/13/65259.aspx
 
  MEMORY_BASIC_INFORMATION mbi;
  static int dummy;
  VirtualQuery( &dummy, &mbi, sizeof(mbi) );
 
  return reinterpret_cast<HMODULE>(mbi.AllocationBase);
 
#else    // VC 7.0
  // from ATL 7.0 sources
 
  return reinterpret_cast<HMODULE>(&__ImageBase);
#endif
}

//Determine if the current process is elevated 
BOOL IsElevated() {
	BOOL fRet = FALSE;
	HANDLE hToken = NULL;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
		TOKEN_ELEVATION Elevation;
		DWORD cbSize = sizeof(TOKEN_ELEVATION);
		if (GetTokenInformation(hToken, TokenElevation, &Elevation, sizeof(Elevation), &cbSize)) {
			fRet = Elevation.TokenIsElevated;
		}
	}
	if (hToken) {
		CloseHandle(hToken);
	}
	return fRet;
}

/*Show the integrity level of either the current or specified process
* Use PID of 0 to open the current process
* Code adapted from: https://msdn.microsoft.com/en-us/library/bb625966.aspx
* Return Values:
* -1 Something went wrong
* 1 Low Integrity Process
* 2 Medium Integrity Process
* 3 High Integrity Process
* 4 System Integrity Process
* 5 Access Denied, the Process is higher level than low
* 6 Access Denied, the Process is higher level than medium
* 7 Access Denied, the Process is higher level than medium
*/
DWORD GetProcessIntegrityLevel(DWORD dwPID)
{
	HANDLE hToken;
	HANDLE hProcess;

	DWORD dwLengthNeeded;
	DWORD dwError = ERROR_SUCCESS;

	PTOKEN_MANDATORY_LABEL pTIL = NULL;
	LPWSTR pStringSid;
	DWORD dwIntegrityLevel;

	//Select the process to query
	if (dwPID != 0) {
		hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, dwPID);
	}
	else {
		hProcess = GetCurrentProcess();
	}

	//Make sure we have a solid handle on the process
	//TODO: If this is access denied, we need a way to report back that the process is higher than X
	if (hProcess == NULL) {
		if (GetLastError() == 5) { //Access denied, which means the process integrity level is higher than current
			//Check current integrity level
			DWORD CurrentIntegrityLvl = GetProcessIntegrityLevel(0);
			switch (CurrentIntegrityLvl) {
				case 1:
					//the Process is higher level than low
					return 5;
				case 2:
					//the Process is higher level than med
					return 6;
				case 3:
					//the Process is higher level than high
					return 7;
			}
		}else {
			ODSDisplayError(TEXT("ProcIntegrityLvl: Failed to get handle to process"));
			return -1;
		}
	}

	if (OpenProcessToken(hProcess, TOKEN_QUERY, &hToken))
	{
		// Get the Integrity level.
		if (!GetTokenInformation(hToken, TokenIntegrityLevel,
			NULL, 0, &dwLengthNeeded))
		{
			dwError = GetLastError();
			if (dwError == ERROR_INSUFFICIENT_BUFFER)
			{
				pTIL = (PTOKEN_MANDATORY_LABEL)LocalAlloc(0,
					dwLengthNeeded);
				if (pTIL != NULL)
				{
					if (GetTokenInformation(hToken, TokenIntegrityLevel,
						pTIL, dwLengthNeeded, &dwLengthNeeded))
					{
						dwIntegrityLevel = *GetSidSubAuthority(pTIL->Label.Sid,
							(DWORD)(UCHAR)(*GetSidSubAuthorityCount(pTIL->Label.Sid) - 1));

						if (dwIntegrityLevel == SECURITY_MANDATORY_LOW_RID)
						{
							// Low Integrity
							return 1;
						}
						else if (dwIntegrityLevel >= SECURITY_MANDATORY_MEDIUM_RID &&
							dwIntegrityLevel < SECURITY_MANDATORY_HIGH_RID)
						{
							// Medium Integrity
							return 2;
						}
						else if (dwIntegrityLevel >= SECURITY_MANDATORY_HIGH_RID)
						{
							// High Integrity
							return 3;
						}
						else if (dwIntegrityLevel >= SECURITY_MANDATORY_SYSTEM_RID)
						{
							// System Integrity
							return 4;
						}
					}
					LocalFree(pTIL);
				}
			}
		}
		CloseHandle(hToken);
	}
}

//Get an embedded RCDATA resource and return it to the caller as string
//NOTE: It is up to the caller to free the allocated string
LPCWSTR GetResourceAsLPCWSTR(HMODULE hDLL, int ResourceID) {
	//Get a handle to the embedded resource(s) 
	HRSRC rcStringResource = FindResource(hDLL, MAKEINTRESOURCE(ResourceID), RT_RCDATA);
	if (rcStringResource == NULL) {
		ODSDisplayError(TEXT("Could not get handle to resource"));
	}
	unsigned int DropFileSize = SizeofResource(hDLL, rcStringResource);
	if (DropFileSize == 0) {
		ODSDisplayError(TEXT("Could not get size of resource "));
	}
	HGLOBAL hStringResourceData = LoadResource(hDLL, rcStringResource);

	//Get the data as a char (since the file is in ANSI/Multibyte encoding)
	LPSTR pCharStringData = (LPSTR)LockResource(hStringResourceData);

	//Convert to WChar
	LPCWSTR pWCharStringData = CharToWChar(pCharStringData);

	return pWCharStringData;
}