#pragma once
#include <Windows.h>
#include <Wbemidl.h>
#include <comdef.h>

#pragma comment(lib, "wbemuuid.lib")

//Struct to hold the instance variables
struct WMILogInstance
{
	LPWSTR LOG_MUTEX;
	IWbemServices *pSvc;
	IWbemLocator *pLoc;
	LPWSTR WMI_CLASS_NAME;
	unsigned int message_num;
};

DWORD SetupWMILogging(WMILogInstance* liWMILogger);
void CleanupWMILogging(WMILogInstance* liWMILogger);
void currentTimestamp(WMILogInstance* liWMILogger, wchar_t* result);
int WriteWMILog (WMILogInstance* liWMILogger, char* message);
int WriteWMILog (WMILogInstance* liWMILogger, LPWSTR message);
int CreateClass(WMILogInstance* liWMILogger);