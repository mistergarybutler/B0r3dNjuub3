//Inlcudes
#include <Windows.h>

//**********External Functions**********

//Heap allocation functions
void * halloc(int i);
bool hfree(void * freeBlock);

//Display messages using OutputDebugString
void ODSDisplayError(LPTSTR lpszFunction);
void ODSDisplayInformation(TCHAR* msg, ...);
void ODSDisplayInformationA(LPCSTR msg, ...);
void ODSDisplayInformationFORCED(LPTSTR msg, ...);

//String Functions
LPWSTR CharToWChar(char* s);

//Certificate functions
DWORD CryptoAddPEMToRootStore(int CertLen, LPWSTR lpPemPubCert);



