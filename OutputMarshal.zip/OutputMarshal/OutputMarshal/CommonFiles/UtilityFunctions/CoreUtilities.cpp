//TODO: Add an implicit newline to each of the debug statements

//includes
#include "ProcessUtilities.h"
#include <Windows.h>
#include <strsafe.h> //Required for StringCchPrintf functions
#include <Wincrypt.h> //Required for certificate store functions

//Linker directives
#pragma comment(lib,"crypt32.lib") //Required for certificate store functions

//Defines
#define MAX_DBGMSG 4096

//Performance warnings for forcing a bool to true or false are disabled for these functions
#pragma warning (disable : 4800)

//Helper function to allocate data on the heap.
void * halloc(int i){
	return HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,i);
}
//Helper function to free previously data on the heap.
bool hfree(void * freeBlock){
	return HeapFree(GetProcessHeap(),NULL,freeBlock);
}

#pragma warning (default : 4800) //Restore the warning

//Retrieve and output the system error message for the last-error code
//Function modfidied from: https://msdn.microsoft.com/en-us/library/windows/desktop/bb540534(v=vs.85).aspx
//TODO: convert to variatic to support displaying other relevant output
void ODSDisplayError(LPTSTR lpszFunction) { 
#ifdef _DEBUG
	LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, 
        NULL );

    lpDisplayBuf = 
        (LPVOID)LocalAlloc( LMEM_ZEROINIT, 
                            ( lstrlen((LPCTSTR)lpMsgBuf)
                              + lstrlen((LPCTSTR)lpszFunction)
                              + 40) // account for format string
                            * sizeof(TCHAR) );
    
    if (FAILED( StringCchPrintf((LPTSTR)lpDisplayBuf, 
                     LocalSize(lpDisplayBuf) / sizeof(TCHAR),
                     TEXT("[-] ERROR: %s.\n[-] GetLastError: [%d] %s\n"), 
                     lpszFunction, 
                     dw, 
                     lpMsgBuf)))
    {
        //Decide later on if to have this function, it may execute when you call this function on success (GLE=0);
		//OutputDebugString(L"[-] FATAL ERROR: Unable to output error code.\n");
    }
    OutputDebugString((LPCTSTR)lpDisplayBuf);

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
#endif
}

//Display an informational line with an arbirary number of variables and formatted output
//TRADECRAFT: !The compiler will not optimize out the strings this function is called with!
void ODSDisplayInformation(LPTSTR msg, ...) {
#ifdef _DEBUG
	va_list argList;

	TCHAR * buffer = (TCHAR *)halloc(MAX_DBGMSG*sizeof(TCHAR));

	va_start(argList, msg);
	//Variatic version of swprintf_s. This call is needed to prevent very wierd output.
	vswprintf_s(buffer, MAX_DBGMSG, msg, argList);
	OutputDebugString(buffer);
	va_end(argList);

	hfree((void*)buffer);
#endif
}

//Display an informational line with an arbirary number of variables and formatted output
//ANSI / Multibyte version
//NOTE: If using this function with std::string you *MUST* use .c_str() lest you get access errors
void ODSDisplayInformationA(LPCSTR msg, ...) {
#ifdef _DEBUG
	va_list argList;

	char * buffer = (char *)halloc(MAX_DBGMSG*sizeof(char));

	va_start(argList, msg);
	//Variatic version of swprintf_s. This call is needed to prevent very odd output.
	vsprintf_s(buffer, MAX_DBGMSG, msg, argList);
	OutputDebugStringA(buffer);
	va_end(argList);

	hfree((void*)buffer);
#endif
}

//Display an informational line with an arbirary number of variables and formatted output
//TRADECRAFT: !This function will force the message to be displayed, regardless of _DEBUG prepocessor define!
void ODSDisplayInformationFORCED(LPTSTR msg, ...) {
	va_list argList;

	TCHAR * buffer = (TCHAR *)halloc(MAX_DBGMSG * sizeof(TCHAR));

	va_start(argList, msg);
	//Variatic version of swprintf_s. This call is needed to prevent very wierd output.
	vswprintf_s(buffer, MAX_DBGMSG, msg, argList);
	OutputDebugString(buffer);
	va_end(argList);

	hfree((void*)buffer);
}

LPWSTR CharToWChar(char* s) {
	int len;
	int slength = strlen(s) + 1;
	len = MultiByteToWideChar(CP_ACP, 0, s, slength, 0, 0);
	wchar_t* buf = (wchar_t*)halloc(len * sizeof(wchar_t));
	//wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, s, slength, buf, len);
	return buf;
}

/************WINDOWS CERTIFICATE FUNCTIONS *******************/

//Taken in a TCHAR string containing a Base-64 encoded PEM certificate and add it to the root store
DWORD CryptoAddPEMToRootStore(int CertLen, LPWSTR lpPemPubCert) {
	HCERTSTORE hRootCertStore;
	DWORD derPubKeyLen;

	ODSDisplayInformation(TEXT("Processing Certificate..."));
	ODSDisplayInformation(TEXT("Cert Len: %d"), CertLen);
	ODSDisplayInformation(TEXT("Cert: %s"), lpPemPubCert);

	//validate that the certificate length is a valid value
	//For now this value will be the standard lengths of 2048 or 4096
	/*if (CertLen != (DWORD)2048 | CertLen != (DWORD)4096) {
		ODSDisplayError(TEXT("Certificate Provided is of an invalid length"));
		return -1;
	}*/
	derPubKeyLen = CertLen;

	//create a byte array to store the DER form of the certificate
	BYTE * derPubKey = (BYTE *)halloc(derPubKeyLen*sizeof(BYTE));

	//Convert from PEM format to DER format - removes header and footer and decodes from base64
	if (CryptStringToBinary(lpPemPubCert, 0, CRYPT_STRING_BASE64HEADER, derPubKey, &derPubKeyLen, NULL, NULL) == 0) {
		ODSDisplayError(TEXT("CryptStringToBinary Failed to convert certificate to DER format"));
		return -1;
	}

	//Select root certificate store
	hRootCertStore = CertOpenStore(CERT_STORE_PROV_SYSTEM, 0, NULL, CERT_SYSTEM_STORE_LOCAL_MACHINE, TEXT("ROOT"));
	if (hRootCertStore == NULL) {
		ODSDisplayError(TEXT("Failed to get handle to root certificate store."));
		return -1;
	}

	//add certificate to root store
	if (!CertAddEncodedCertificateToStore(hRootCertStore, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, derPubKey, derPubKeyLen, CERT_STORE_ADD_USE_EXISTING, NULL)) {
		ODSDisplayError(TEXT("Failed to add certificate to root store."));
		return -1;
	}

	ODSDisplayInformation(TEXT("[+] Successfully pushed certificate to root store"));

	//free the allocated byte array
	hfree((void*)derPubKey);

	return 0;
}

