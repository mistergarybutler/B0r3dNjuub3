// #######################################################################
// ############ HEADER FILES
// #######################################################################
#include "FileUtilities.h"

#define MAX_DBGMSG 4096
#define MakePtr(cast, ptr, addValue) (cast)((DWORD)(ptr) + (DWORD)(addValue))
#pragma comment(lib, "imagehlp.lib" )
#pragma comment(lib, "Shlwapi.lib") //Needed for PathFileExists et al

///////////////////////////////////////////////////////////////////////////////
// CodeView debug information structures
//
#define CV_SIGNATURE_NB10 '01BN' //This is little endian byte order,
#define CV_SIGNATURE_RSDS 'SDSR' //because we'll read them in as DWORDs.

// CodeView header
struct CV_HEADER
{
	DWORD CvSignature; // NBxx
	LONG Offset; // Always 0 for NB10
};

// CodeView NB10 debug information
// (used when debug information is stored in a PDB 2.00 file)
struct CV_INFO_PDB20
{
	CV_HEADER Header;
	DWORD Signature; // seconds since 01.01.1970
	DWORD Age; // an always-incrementing value
	BYTE PdbFileName[1]; // zero terminated string with the name of the PDB file
};

// CodeView RSDS debug information
// (used when debug information is stored in a PDB 7.00 file)
struct CV_INFO_PDB70
{
	DWORD CvSignature;
	GUID Signature; // unique identifier
	DWORD Age; // an always-incrementing value
	BYTE PdbFileName[1]; // zero terminated string with the name of the PDB file
};

bool CheckDosHeader(PIMAGE_DOS_HEADER pDosHeader);
bool CheckNtHeaders(PIMAGE_NT_HEADERS pNtHeaders);
bool CheckSectionHeaders(PIMAGE_NT_HEADERS pNtHeaders);
bool CheckDebugDirectory(PIMAGE_DEBUG_DIRECTORY pDebugDir, DWORD DebugDirSize);
bool IsPE32Plus(PIMAGE_OPTIONAL_HEADER pOptionalHeader, bool& bPE32Plus);
int CleanCodeViewDebugInfo(LPBYTE pTargetDebugInfo, DWORD TargetDebugInfoSize);
int CleanCodeViewDebugInfo(LPBYTE pTargetDebugInfo, DWORD TargetDebugInfoSize, char* SourcePdbFileName);
int CleanDebugDirectoryEntry(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir);
int CleanDebugDirectoryEntry(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, char* SourcePdbFileName);
int CleanDebugDirectoryEntries(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, DWORD TargetDebugDirSize);
int CleanDebugDirectoryEntries(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, DWORD TargetDebugDirSize, char* SourcePdbFileName);
bool GetFileOffsetFromRVA(PIMAGE_NT_HEADERS pNtHeaders, DWORD Rva, DWORD& FileOffset);
bool GetDebugDirectoryRVA(PIMAGE_OPTIONAL_HEADER pOptionalHeader, DWORD& DebugDirRva, DWORD& DebugDirSize);



//Function to take a path name ex: C:\test\thisIsATest\test and reduce one level to C:\test\thisIsATest
//returns null when it cannot be reduced further
//**NOTE** has not been tested for drive letters other than C:
LPWSTR pathStripper(LPWSTR oldPath) {
	LPWSTR newPath;
	size_t offset = 0;
	// Get the offset of the last \ in the string
	for (int i = 0; i < wcslen(oldPath); i++) {
		if (oldPath[i] == '\\') {
			offset = i;
		}
	}
	// If it cannot be shortened retrun null
	if (offset == 0)
		return NULL;
	//get and retrun the newly reduced path
	newPath = new WCHAR[offset + 1]; //
	wcsncpy_s(newPath, offset + 1, oldPath, offset);
	return newPath;
}

//Recursive function to create a path. Takes in a full directory and keeps going backwards to find a directory that exists, then starts building
DWORD CreatePath(LPWSTR lpDirectoryPath) {
	//Since this function is recursive, we need a local variable to store the current directory
	TCHAR TempPath[MAX_PATH] = { 0 };
	WCHAR *newPath; //variable to store the reduced path
	swprintf_s(TempPath, MAX_PATH, L"%s", lpDirectoryPath);
	//If the current path exists, return the function back
	if (PathFileExists(lpDirectoryPath)) {
		return 0;
	}
	//Strip off a folder and call CreatePath again
	newPath = pathStripper(lpDirectoryPath);
	if (newPath != NULL) {

		ODSDisplayInformation(L"[+] Shottening the directory path: %s", lpDirectoryPath);
		CreatePath(newPath);
	}

	//Create the directory
	if (CreateDirectory(TempPath, NULL)) {
		//Set the Directory to Hidden
		ODSDisplayInformation(L"[+] Directory successfully created: %s", lpDirectoryPath);
		return 1;
	}
	else {
		ODSDisplayError(L"creation failed");
	}

	return 0;
}


//Drop packed files to the specified directory
DWORD DropFiles(HMODULE hDLL, int ResourceID, LPWSTR lpDropFilePath, DWORD Attributes) {
	DWORD dwBytesWritten = 0;

	//Get a handle to the embedded resource(s) 
	HRSRC rcDropFile = FindResource(hDLL, MAKEINTRESOURCE(ResourceID), RT_RCDATA);
	if (rcDropFile == NULL) {
		ODSDisplayError(L"Could not get handle to resource");
	}
	unsigned int DropFileSize = SizeofResource(hDLL, rcDropFile);
	if (DropFileSize == 0) {
		ODSDisplayError(L"Could not get size of resource");
	}
	HGLOBAL DropFileData = LoadResource(hDLL, rcDropFile);

	void* pDropFileBinaryData = LockResource(DropFileData);

	//Write embedded resource to disk
	HANDLE hDropFile = CreateFile(lpDropFilePath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, Attributes, NULL);
	if (hDropFile == INVALID_HANDLE_VALUE) {
		ODSDisplayError(L"Failed to get handle to write resource");
		return -1;
	}
	if (WriteFile(hDropFile, (char*)pDropFileBinaryData, DropFileSize, &dwBytesWritten, NULL)) {
		ODSDisplayInformation(L"[+] Wrote %ld bytes of resource %s with size=%ld\n", dwBytesWritten, lpDropFilePath, DropFileSize);

	}
	else {
		ODSDisplayError(L"Something went wrong writing the resource to disk");
		return -1;
	}

	//Close handles
	CloseHandle(hDropFile);

	return 0;
}

//returns 1 on success returns 0 on fail
int CopyVersionInformation(LPWSTR targetPath, LPWSTR sourcePath) {
	HGLOBAL hResLoad;   // handle to loaded resource
	HMODULE hSource;       // handle to existing .EXE file
	HRSRC hRes;         // handle/ptr. to res. info. in hExe
	HANDLE hUpdateRes;  // update resource handle
	LPVOID lpResLock;   // pointer to resource data
	BOOL result;

	// Load the source file that contains the dialog box you want to copy.
	hSource = LoadLibrary(sourcePath);
	if (hSource == NULL)
	{
		ODSDisplayError(L"Could not load source");
		return 0;
	}

	// Locate the dialog box resource in the .EXE file.
	hRes = FindResource(hSource, MAKEINTRESOURCE(VS_VERSION_INFO), RT_VERSION);
	if (hRes == NULL)
	{
		ODSDisplayError(L"Could not find version information from source");
		return 0;
	}

	// Load the dialog box into global memory.
	hResLoad = LoadResource(hSource, hRes);
	if (hResLoad == NULL)
	{
		ODSDisplayError(L"Could not load version information from source");
		return 0;
	}

	// Lock the dialog box into global memory.
	lpResLock = LockResource(hResLoad);
	if (lpResLock == NULL)
	{
		ODSDisplayError(L"Could not load version information from source");
		return 0;
	}

	// Open the file to which you want to add the dialog box resource.
	hUpdateRes = BeginUpdateResource(targetPath, FALSE);
	if (hUpdateRes == NULL)
	{
		ODSDisplayError(L"Could not open the target file");
		return 0;
	}

	// Add the dialog box resource to the update list.
	result = UpdateResource(hUpdateRes,    // update resource handle
		RT_VERSION,                         // change dialog box resource
		MAKEINTRESOURCE(VS_VERSION_INFO),         // dialog box id
		MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL),  // neutral language
		lpResLock,                         // ptr to resource info
		SizeofResource(hSource, hRes));       // size of resource info

	if (result == FALSE)
	{
		ODSDisplayError(L"Could not add version info to the target file");
		return 0;
	}

	// Write changes to FOOT.EXE and then close it.
	if (!EndUpdateResource(hUpdateRes, FALSE))
	{
		ODSDisplayError(L"Could not write changes to target file");
		return 0;
	}

	// Clean up.
	if (!FreeLibrary(hSource))
	{
		ODSDisplayError(L"Could not free the source file");
		return 0;
	}

	ODSDisplayInformation(L"[+] Successfully copies version information");
	return 1;
}

//create a path that is time stomped. Returns 1 on success and 0 on error.
DWORD TimeStompPath(LPWSTR targetFile, TCHAR* sourceFile, int levels) {
	int maxLevels = 0;
	HRESULT hr;

	//if we need to timestomp a folder we need backup privs
	hr = ModifyPrivilege(SE_RESTORE_NAME, TRUE);
	hr = ModifyPrivilege(SE_BACKUP_NAME, TRUE);

	//make sure you can go that many levels up the directory stucture
	for (int i = 0; i < lstrlen(targetFile); i++) {
		if (targetFile[i] == '\\') {
			maxLevels++;
		}
	}

	if (maxLevels < levels) {
		ODSDisplayInformation(L"[*] path does not contain %d files/directorys limiting timestomping to %d", levels, maxLevels);
		levels = maxLevels;
	}

	for (int i = 0; i < levels; i++) {
		TimeStomp(targetFile, sourceFile);
		StrCpy(targetFile, pathStripper((LPWSTR)targetFile));
	}
	return 1;
}

/* returns 0 on error, 1 on success. this function set the MACE values based on
the input from the FILE_BASIC_INFORMATION structure */
DWORD TimeStomp(TCHAR* targetFile, TCHAR* sourceFile) {
	HANDLE fileToModify, fileToCopy;
	FILE_BASIC_INFORMATION fbiToCopy;



	ODSDisplayInformation(L"[+] about to TimeStomp %s", targetFile);
	fileToCopy = RetrieveFileBasicInformation(sourceFile, &fbiToCopy);
	if (fileToCopy == NULL) {
		ODSDisplayError(L" failed to get handle  to source file");
		CloseHandle(sourceFile);
		return 0;
	}
	//Create file with FILE_FLAG_BACKUP_SEMANTICS (this ensures we can timestome a folder). without it folder handles will not be granted
	//If timestomp is failing try the following two commands 
	//ModifyPrivilege(SE_BACKUP_NAME, TRUE); 
	//ModifyPrivilege(SE_RESTORE_NAME, TRUE);
	fileToModify = CreateFile(targetFile, FILE_READ_ATTRIBUTES | GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (fileToModify == NULL) {
		ODSDisplayError(L"failed to get handle for target file");
		CloseHandle(fileToModify);
		return 0;
	}
	if (SetFileMACE(fileToModify, fbiToCopy) == 0) {
		ODSDisplayInformation(L"[+] Successfully TimeStompped %s", targetFile);
		CloseHandle(fileToCopy);
		CloseHandle(fileToModify);
		return 1;
	}
	else {
		ODSDisplayError(L"failed to modify file");
		CloseHandle(fileToCopy);
		CloseHandle(fileToModify);
		return 0;
	}
	ODSDisplayError(L"Failed to TimeStomp file");
	CloseHandle(fileToCopy);
	CloseHandle(fileToModify);
	return 0;
}

/* returns 1 on error, 0 on success, returns 5 on access violation. this function set the MACE values based on
the input from the FILE_BASIC_INFORMATION structure */
DWORD SetFileMACE(HANDLE file, FILE_BASIC_INFORMATION fbi) {

	HMODULE ntdll = NULL;
	IO_STATUS_BLOCK iostatus;
	pNtSetInformationFile NtSetInformationFile = NULL;

	ntdll = LoadLibrary(L"ntdll.dll");
	if (ntdll == NULL) {
		ODSDisplayError(L"TimeStomp Failed to get ntdll.dll");
		return 1;
	}

	NtSetInformationFile = (pNtSetInformationFile)GetProcAddress(ntdll, "NtSetInformationFile");
	if (NtSetInformationFile == NULL) {
		ODSDisplayError(L"TimeStomp Failed to get NtSetImformationFile");
		return 1;
	}

	if (NtSetInformationFile(file, &iostatus, &fbi, sizeof(FILE_BASIC_INFORMATION), FileBasicInformation) < 0) {
		ODSDisplayError(L"failed to set time for file");
		if (GetLastError() == 5) { // access denied
			return 5;
		}
		return 1;
	}

	/* clean up */
	FreeLibrary(ntdll);
	ODSDisplayInformation(L"[+] MACE changed on file \n");
	return 0;
}

/* returns the handle on success or NULL on failure. this function opens a file and returns
the FILE_BASIC_INFORMATION on it. */
HANDLE RetrieveFileBasicInformation(TCHAR* filename, FILE_BASIC_INFORMATION *fbi) {

	HANDLE file = NULL;
	HMODULE ntdll = NULL;
	pNtQueryInformationFile NtQueryInformationFile = NULL;
	IO_STATUS_BLOCK iostatus;
	//file = CreateFile(filename, FILE_GENERIC_READ | FILE_GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL); //old version did not work
	file = CreateFile(filename, FILE_GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (file == INVALID_HANDLE_VALUE) {
		ODSDisplayError(L"failed to get handle for file");
		return 0;
	}

	/* load ntdll and retrieve function pointer */
	ntdll = LoadLibrary(L"ntdll.dll");
	if (ntdll == NULL) {
		ODSDisplayError(L"TimeStomp Failed to get ntdll.dll");
		CloseHandle(file);
		return 0;
	}

	/* retrieve current timestamps including file attributes which we want to preserve */
	NtQueryInformationFile = (pNtQueryInformationFile)GetProcAddress(ntdll, "NtQueryInformationFile");
	if (NtQueryInformationFile == NULL) {
		CloseHandle(file);
		ODSDisplayError(L"TimeStomp Failed to get time information file");
		return 0;
	}

	/* obtain the current file information including attributes */
	if (NtQueryInformationFile(file, &iostatus, fbi, sizeof(FILE_BASIC_INFORMATION), FileBasicInformation) < 0) {
		CloseHandle(file);
		ODSDisplayError(L"TimeStomp Failed to get attribute information");
		return 0;
	}

	ODSDisplayInformation(L"[+] Retrieved information for file %s \n", filename);
	/* clean up */
	FreeLibrary(ntdll);

	return file;
}

// returns 0 on error, 1 on success. this function converts a SYSTEMTIME structure to a LARGE_INTEGER
DWORD ConvertLocalTimeToLargeInteger(SYSTEMTIME localsystemtime, LARGE_INTEGER *largeinteger) {

	// the local time is stored in the system time structure argument which should be from the user
	// input. the user inputs the times in local time which is then converted to utc system time because
	// ntfs stores all timestamps in utc, which is then converted to a large integer

	// MSDN recommends converting SYSTEMTIME to FILETIME via SystemTimeToFileTime() and
	// then copying the values in FILETIME to a ULARGE_INTEGER structure.

	FILETIME filetime;
	FILETIME utcfiletime;
	DWORD result = 0;

	// convert the SYSTEMTIME structure to a FILETIME structure
	if (SystemTimeToFileTime(&localsystemtime, &filetime) == 0) {
		return 0;
	}

	// convert the local file time to UTC
	if (LocalFileTimeToFileTime(&filetime, &utcfiletime) == 0) {
		return 0;
	}

	/* copying lowpart from a DWORD to DWORD, and copying highpart from a DWORD to a LONG.
	potential data loss of upper values 2^16, but acceptable bc we wouldn't be able to set
	this high even if we wanted to because NtSetInformationFile() takes a max of what's
	provided in LARGE_INTEGER */
	largeinteger->LowPart = utcfiletime.dwLowDateTime;
	largeinteger->HighPart = utcfiletime.dwHighDateTime;

	return 1;
}

/* returns 0 on error, 1 on success. this function converts a LARGE_INTEGER to a SYSTEMTIME structure */
DWORD ConvertLargeIntegerToLocalTime(SYSTEMTIME *localsystemtime, LARGE_INTEGER largeinteger) {

	FILETIME filetime;
	FILETIME localfiletime;
	DWORD result = 0;

	filetime.dwLowDateTime = largeinteger.LowPart;
	filetime.dwHighDateTime = largeinteger.HighPart;

	if (FileTimeToLocalFileTime(&filetime, &localfiletime) == 0) {
		return 0;
	}

	if (FileTimeToSystemTime(&localfiletime, localsystemtime) == 0) {
		return 0;
	}

	return 1;
}

/* returns 1 on success or 0 on failure. this function converts an input string into a SYSTEMTIME structure */
DWORD ParseDateTimeInput(char *inputstring, SYSTEMTIME *systemtime) {

	char day[10];
	char daynight[3];

	if (sscanf(inputstring, "%9s %hu/%hu/%hu %hu:%hu:%hu %2s", day, &systemtime->wMonth, &systemtime->wDay, &systemtime->wYear, &systemtime->wHour, &systemtime->wMinute, &systemtime->wSecond, daynight) == 0) {
		return 0;
	}

	/* sanitize input */
	if (strlen(day) > 0) {
		CharLowerA(day);
	}
	else {
		return 0;
	}

	do {
		if (day[0] == 'm') { if (strncmp(day, "monday", 6) == 0) { systemtime->wDayOfWeek = 1; break; } }
		if (day[0] == 't') {
			if (strncmp(day, "tuesday", 7) == 0) { systemtime->wDayOfWeek = 2; break; }
			if (strncmp(day, "thursday", 8) == 0) { systemtime->wDayOfWeek = 4; break; }
		}
		if (day[0] == 'w') { if (strncmp(day, "wednesday", 9) == 0) { systemtime->wDayOfWeek = 3; break; } }
		if (day[0] == 'f') { if (strncmp(day, "friday", 6) == 0) { systemtime->wDayOfWeek = 5; break; } }
		if (day[0] == 's') {
			if (strncmp(day, "saturday", 8) == 0) { systemtime->wDayOfWeek = 6; break; }
			if (strncmp(day, "sunday", 6) == 0) { systemtime->wDayOfWeek = 0; break; }
		}

		return 0;
	} while (0);


	if (systemtime->wMonth < 1 || systemtime->wMonth > 12) {
		return 0;
	}
	if (systemtime->wDay < 1 || systemtime->wDay > 31) {
		return 0;
	}
	if (systemtime->wYear < 1601 || systemtime->wYear > 30827) {
		return 0;
	}

	if (strlen(daynight) > 0) {
		CharLowerA(daynight);
	}
	else {
		return 0;
	}
	if (strncmp(daynight, "am", 2) == 0) {
		if (systemtime->wHour < 1 || systemtime->wHour > 12) {
			return 0;
		}
	}
	else if (strncmp(daynight, "pm", 2) == 0) {
		if (systemtime->wHour < 1 || systemtime->wHour > 12) {
			return 0;
		}
		if (systemtime->wHour != 12) { systemtime->wHour += 12; }
	}
	else {
		return 0;
	}

	if (systemtime->wMinute < 0 || systemtime->wMinute > 59) {
		return 0;
	}
	if (systemtime->wSecond < 0 || systemtime->wSecond > 59) {
		return 0;
	}

	/* it doesnt matter what the millisecond value is because the ntfs resolution for file timestamps is only up to 1s */
	systemtime->wMilliseconds = 0;

	return 1;
}

// takes a file a sets the time values to the minimum possible value, return 1 on success or 0 on failure
DWORD SetMinimumTimeValues(TCHAR *filename) {

	HANDLE file = NULL;
	FILE_BASIC_INFORMATION fbi;
	SYSTEMTIME userinputtime;

	// open the file and retrieve information
	file = RetrieveFileBasicInformation(filename, &fbi);
	if (file == NULL) {
		return 0;
	}

	userinputtime.wYear = 1601;
	userinputtime.wMonth = 1;
	userinputtime.wDayOfWeek = 0;
	userinputtime.wDay = 1;
	userinputtime.wHour = 0;
	userinputtime.wMinute = 0;
	userinputtime.wSecond = 0;
	userinputtime.wMilliseconds = 0;
	if ((ConvertLocalTimeToLargeInteger(userinputtime, &fbi.ChangeTime) == 0) || (ConvertLocalTimeToLargeInteger(userinputtime, &fbi.CreationTime) == 0) ||
		(ConvertLocalTimeToLargeInteger(userinputtime, &fbi.LastAccessTime) == 0) || (ConvertLocalTimeToLargeInteger(userinputtime, &fbi.LastWriteTime) == 0)) {
		return 0;
	}
	if (SetFileMACE(file, fbi) == 0) { return 0; }

	return 1;
}

// this function recursively blanks all files from the specified directory so that EnCase cannot see anything
DWORD TheCraigOption(LPWSTR directoryname) {

	// general variables
	HANDLE file = NULL;
	TCHAR currentfiletarget[MAX_PATH + 1];

	// file search variables
	HANDLE find = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA FindFileData;
	TCHAR fulldirectorypath[MAX_PATH + 1];

	// set the target directories
	lstrcpyn(fulldirectorypath, directoryname, lstrlen(directoryname) + 1);
	lstrcat(fulldirectorypath, L"\\*");

	// search the directory
	find = FindFirstFile(fulldirectorypath, &FindFileData);
	if (find == INVALID_HANDLE_VALUE) {
		if (GetLastError() == 5) { // access denied
			return 1;
		}
		return 0;
	}

	// recursively call TheCraigOption if the file type is a directory
	if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
		if ((lstrcmp(FindFileData.cFileName, L".") != 0) && (lstrcmp(FindFileData.cFileName, L"..") != 0)) {
			lstrcpyn(currentfiletarget, directoryname, lstrlen(directoryname) + 1);
			lstrcat(currentfiletarget, L"\\");
			lstrcat(currentfiletarget, FindFileData.cFileName);
			if (TheCraigOption(currentfiletarget) == 0) {
				return 0;
			}
		}
	}
	else {
		// set the full file name and lower the time values
		lstrcpyn(currentfiletarget, directoryname, lstrlen(directoryname) + 1);
		lstrcat(currentfiletarget, L"\\");
		lstrcat(currentfiletarget, FindFileData.cFileName);
		if (SetMinimumTimeValues(currentfiletarget) == 0) {
			//return 0;
		}
	}

	// recursively set all values
	while (FindNextFile(find, &FindFileData) != 0) {

		// recursively call TheCraigOption if the file type is a directory
		if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			if ((lstrcmp(FindFileData.cFileName, L".") != 0) && (lstrcmp(FindFileData.cFileName, L"..") != 0)) {
				lstrcpyn(currentfiletarget, directoryname, lstrlen(directoryname) + 1);
				lstrcat(currentfiletarget, L"\\");
				lstrcat(currentfiletarget, FindFileData.cFileName);
				if (TheCraigOption(currentfiletarget) == 0) {
					return 0;
				}
			}
		}
		else {
			// set the full file name and lower the time values
			lstrcpyn(currentfiletarget, directoryname, lstrlen(directoryname) + 1);
			lstrcat(currentfiletarget, L"\\");
			lstrcat(currentfiletarget, FindFileData.cFileName);
			if (SetMinimumTimeValues(currentfiletarget) == 0) {
				//return 0;
			}
		}
	}

	// cleanup find data structures
	if (FindClose(find) == 0) {
		return 0;
	}
	if (GetLastError() != ERROR_NO_MORE_FILES) {
		if (GetLastError() == 5) { // access denied
			return 1;
		}
		return 0;
	}

	return 1;
}

//This function is use to mimic the compilation time of another file.
//It will parse the PE header to determine the location of the compliation time
//It will then copy the compilation time from a source file.
int ModifyFileCompileTime(LPWSTR filePath, LPWSTR fileToMimic) {
	UCHAR* sourceFileData;
	UCHAR* targetFileData;
	HANDLE hTargetFile, hSourceFile;
	DWORD sourceFilesize;
	DWORD targetFilesize;
	BYTE sourceCompileTime[4];
	DWORD dwBytesWritten;
	OVERLAPPED ol = { 0 };
	DWORD offsetToSourcePE = 0, offsetToTargetPE = 0;
	DWORD HeaderSize = 1000;
	BOOL bErrorFlag = FALSE;

	//get handle for target file
	hTargetFile = CreateFile(filePath,               // file to open
		FILE_GENERIC_READ | FILE_GENERIC_WRITE,          // open for reading
		0,       // grab control of the file
		NULL,                  // default security
		OPEN_EXISTING,         // existing file only
		FILE_ATTRIBUTE_NORMAL, // normal file
		NULL);                 // no attr. template
	if (hTargetFile == INVALID_HANDLE_VALUE) {
		ODSDisplayError(L"Failed to ge handle on target");
		return 0;
	}

	//get the size of the target file can we skip this and read a smaller amount?
	targetFilesize = GetFileSize(hTargetFile, NULL);
	if (targetFilesize <= 0) {
		CloseHandle(hTargetFile);
		return 0;
	}
	if (targetFilesize < HeaderSize) {
		targetFileData = (UCHAR *)memory_allocate(targetFilesize);
	}
	else {
		if (targetFilesize < PE_LOCATION_POINTER_OFFSET + 4) {
			ODSDisplayError(L"Target File too small");
			CloseHandle(hTargetFile);
			return 0;
		}
		targetFileData = (UCHAR *)memory_allocate(HeaderSize);
	}

	//make sure no error with stack allocation
	if (targetFileData == NULL) {
		ODSDisplayError(L"Failed to allocated memory");
		CloseHandle(hTargetFile);
		return 0;
	}
	if (FALSE == ReadFileEx(hTargetFile, targetFileData, HeaderSize - 1, &ol, NULL))
	{
		ODSDisplayError(L"FAILED to read  target file");
		CloseHandle(hTargetFile);
		return 0;
	}

	//grab a handle for the source file
	hSourceFile = CreateFile(fileToMimic,               // file to open
		FILE_GENERIC_READ,          // open for reading
		FILE_SHARE_READ,							// share for reading
		NULL,						// default security
		OPEN_EXISTING,				 // existing file only
		FILE_ATTRIBUTE_NORMAL,		// normal file
		NULL);						// no attr. template

	//if we failed to get a handle return
	if (hSourceFile == INVALID_HANDLE_VALUE) {
		CloseHandle(hTargetFile);
		return 0;
	}

	//attempt the same process for the source file
	sourceFilesize = GetFileSize(hSourceFile, NULL);
	if (sourceFilesize < HeaderSize) {
		sourceFileData = (UCHAR *)memory_allocate(sourceFilesize);
	}
	else {
		if (sourceFilesize < PE_LOCATION_POINTER_OFFSET + 4) {
			ODSDisplayError(L"Source file too small");
			CloseHandle(hTargetFile);
			CloseHandle(hSourceFile);
			return 0;
		}
		sourceFileData = (UCHAR *)memory_allocate(HeaderSize);
	}

	//make sure no error with stack allocation
	if (sourceFileData == NULL) {
		ODSDisplayError(L"Failed to allocated memory");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//read the header data from each file
	if (FALSE == ReadFileEx(hSourceFile, sourceFileData, HeaderSize - 1, &ol, NULL))
	{
		ODSDisplayError(L"FAILED to read file");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//check the source file signature
	byte_stream_copy_to_uint32_little_endian(&sourceFileData[PE_LOCATION_POINTER_OFFSET], offsetToSourcePE);
	if (sourceFileData[offsetToSourcePE] != 'P' || sourceFileData[offsetToSourcePE + 1] != 'E' || sourceFileData[offsetToSourcePE + 2] != '\x00' || sourceFileData[offsetToSourcePE + 3] != '\x00') {
		ODSDisplayError(L"Source Not a PE");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//check the target signature
	byte_stream_copy_to_uint32_little_endian(&targetFileData[PE_LOCATION_POINTER_OFFSET], offsetToTargetPE);
	if (targetFileData[offsetToTargetPE] != 'P' || targetFileData[offsetToTargetPE + 1] != 'E' || targetFileData[offsetToTargetPE + 2] != '\x00' || targetFileData[offsetToTargetPE + 3] != '\x00') {
		ODSDisplayError(L"Target Not a PE");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//make sure the offset we found is good
	if (sourceFilesize < offsetToSourcePE + 12 || targetFilesize < offsetToTargetPE)
	{
		ODSDisplayError(L"PE offset header offset incorrect");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//store the data into a buffer for writing
	for (int i = 0; i < 4; i++) {
		sourceCompileTime[i] = sourceFileData[offsetToSourcePE + 8 + i];
	}

	//seek to the proper location in the file
	DWORD dwPtr = SetFilePointer(hTargetFile,
		offsetToTargetPE + 8,
		NULL,
		FILE_BEGIN);

	if (dwPtr == INVALID_SET_FILE_POINTER) // Test for failure
	{
		ODSDisplayError(L"failed to seek into target file");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//overwrite the compilation time on the target
	bErrorFlag = WriteFile(
		hTargetFile,           // open file handle
		sourceCompileTime,      // start of data to write
		sizeof(sourceCompileTime),  // number of bytes to write
		&dwBytesWritten, // number of bytes that were written
		NULL);            // no overlapped structure

						  //ensure no errors occured
	if (FALSE == bErrorFlag)
	{
		ODSDisplayError(L" Write Error");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}

	//ensure the proper amount of data was written to file
	if (dwBytesWritten != sizeof(sourceCompileTime)) {
		ODSDisplayError(L"Did not write enough");
		CloseHandle(hTargetFile);
		CloseHandle(hSourceFile);
		return 0;
	}
	ODSDisplayInformation(L"[+] Sucessfully modified the PE Compile Time");
	CloseHandle(hTargetFile);
	CloseHandle(hSourceFile);
	return 1;
}

HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable)
{
	HRESULT hr = S_OK;
	TOKEN_PRIVILEGES NewState;
	LUID             luid;
	HANDLE hToken = NULL;

	// Open the process token for this process.
	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
		&hToken))
	{
		ODSDisplayError(L"Failed OpenProcessToken\n");
		return ERROR_FUNCTION_FAILED;
	}

	// Get the local unique ID for the privilege.
	if (!LookupPrivilegeValue(NULL, szPrivilege, &luid))
	{
		CloseHandle(hToken);
		ODSDisplayError(L"Failed LookupPrivilegeValue\n");
		return ERROR_FUNCTION_FAILED;
	}

	// Assign values to the TOKEN_PRIVILEGE structure.
	NewState.PrivilegeCount = 1;
	NewState.Privileges[0].Luid = luid;
	NewState.Privileges[0].Attributes = (fEnable ? SE_PRIVILEGE_ENABLED : 0);

	// Adjust the token privilege.
	if (!AdjustTokenPrivileges(hToken, FALSE, &NewState, 0, NULL, NULL))
	{
		ODSDisplayError(L"Failed AdjustTokenPrivileges\n");
		hr = ERROR_FUNCTION_FAILED;
	}

	// Close the handle.
	CloseHandle(hToken);
	ODSDisplayInformation(L"[+] GOT AdjustTokenPrivileges\n");
	return hr;
}

//will copy a path variable for the pdb information if possible. Otherwise it will simply zero out the information

int pdbPathCopy(LPWSTR FileName, LPWSTR fileToMimic)
{
	// Process the file
	HANDLE hSourceFile = NULL;
	HANDLE hSourceFileMap = NULL;
	LPVOID lpSourceFileMem = 0;

	// Process the file
	HANDLE hTargetFile = NULL;
	HANDLE hTargetFileMap = NULL;
	LPVOID lpTargetFileMem = 0;

	unsigned long ulTargetFileSize = 0;
	//Recalculate the checksum for the file now:
	DWORD dwCurrentChecksum;
	DWORD dwNewChecksum;
	// Look up the debug directory:
	DWORD TargetDebugDirRva = 0;
	DWORD TargetDebugDirSize = 0;
	// Look up the debug directory:
	DWORD SourceDebugDirRva = 0;
	DWORD SourceDebugDirSize = 0;
	UCHAR* sourceFileData;
	OVERLAPPED ol = { 0 };
	bool fail=false;
	do
	{
		// Open the target file and map it into memory:
		hTargetFile = CreateFile(FileName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if ((hTargetFile == INVALID_HANDLE_VALUE) || (hTargetFile == NULL))
		{
			ODSDisplayError(L"Cannot open the target file.");
			break;
		}
		ulTargetFileSize = GetFileSize(hTargetFile, NULL);

		hTargetFileMap = CreateFileMapping(hTargetFile, NULL, PAGE_READWRITE, 0, 0, NULL);
		if (hTargetFileMap == NULL)
		{
			ODSDisplayError(L"Cannot open the target file mapping object");
			break;
		}

		lpTargetFileMem = MapViewOfFile(hTargetFileMap, FILE_MAP_WRITE, 0, 0, 0);
		if (lpTargetFileMem == 0)
		{
			ODSDisplayError(L"Cannot map the Targte file");
			break;
		}

		// Is it a valid PE executable?
		PIMAGE_DOS_HEADER pTargetDosHeader = (PIMAGE_DOS_HEADER)lpTargetFileMem;
		if (!CheckDosHeader(pTargetDosHeader))
		{
			ODSDisplayError(L"Target File is not a PE executable.");
			break;
		}

		PIMAGE_NT_HEADERS pTargetNtHeaders = MakePtr(PIMAGE_NT_HEADERS, pTargetDosHeader, pTargetDosHeader->e_lfanew);
		if (!CheckNtHeaders(pTargetNtHeaders))
		{
			ODSDisplayError(L"Target File is not a PE executable.");
			break;
		}

		if (!CheckSectionHeaders(pTargetNtHeaders))
		{
			ODSDisplayError(L"Target File is not a PE executable.");
			break;
		}


		if (!GetDebugDirectoryRVA(&pTargetNtHeaders->OptionalHeader, TargetDebugDirRva, TargetDebugDirSize))
		{
			ODSDisplayError(L"Target File is not a PE executable.");
			break;
		}

		if ((TargetDebugDirRva == 0) || (TargetDebugDirSize == 0))
		{
			ODSDisplayError(L"Debug target directory not found.");
			break;
		}

		DWORD TargetDebugDirOffset = 0;
		if (!GetFileOffsetFromRVA(pTargetNtHeaders, TargetDebugDirRva, TargetDebugDirOffset))
		{
			ODSDisplayError(L"Debug target directory not found.");
			break;
		}

		PIMAGE_DEBUG_DIRECTORY pTargetDebugDir = MakePtr(PIMAGE_DEBUG_DIRECTORY, lpTargetFileMem, TargetDebugDirOffset);
		if (!CheckDebugDirectory(pTargetDebugDir, TargetDebugDirSize))
		{
			ODSDisplayError(L"Debug target directory is not valid.");
			break;
		}

		// Open source file and map it into memory:
		hSourceFile = CreateFile(fileToMimic,  GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		
		int sourceFilesize = GetFileSize(hSourceFile, NULL);
		sourceFileData = (UCHAR *)memory_allocate(sourceFilesize);

		//make sure no error with stack allocation
		if (sourceFileData == NULL) {
			ODSDisplayError(L"Failed to allocated memory");
			break;
		}

		//read the header data from each file
		if (FALSE == ReadFileEx(hSourceFile, sourceFileData, sourceFilesize, &ol, NULL))
		{
			ODSDisplayError(L"FAILED to read file");
			break;
		}

		// Is it a valid PE executable?
		PIMAGE_DOS_HEADER pSourceDosHeader = (PIMAGE_DOS_HEADER)sourceFileData;
		if (!CheckDosHeader(pSourceDosHeader))
		{
			ODSDisplayError(L"Source file is not a PE executable.");
			fail = true;
			break;
		}

		//make sure the source file is a valid PE
		PIMAGE_NT_HEADERS pSourceNtHeaders = MakePtr(PIMAGE_NT_HEADERS, pSourceDosHeader, pSourceDosHeader->e_lfanew);
		if (!CheckNtHeaders(pSourceNtHeaders))
		{
			ODSDisplayError(L"Source File is not a PE executable.");
			fail = true;
			break;
		}
		if (!CheckSectionHeaders(pSourceNtHeaders))
		{
			ODSDisplayError(L"Source File is not a PE executable.");
			fail = true;
			break;
		}
		
		if (!GetDebugDirectoryRVA(&pSourceNtHeaders->OptionalHeader, SourceDebugDirRva, SourceDebugDirSize))
		{
			ODSDisplayError(L"Source File is not a PE executable.");
			fail = true;
			break;
		}


		//verify the source of debug directory
		if ((SourceDebugDirRva == 0) || (SourceDebugDirSize == 0))
		{
			ODSDisplayError(L"Debug source directory not found.");
			fail = true;
			break;
		}

		DWORD SourceDebugDirOffset = 0;
		if (!GetFileOffsetFromRVA(pSourceNtHeaders, SourceDebugDirRva, SourceDebugDirOffset))
		{
			ODSDisplayError(L"Debug source directory not found.");
			fail = true;
			break;
		}

		PIMAGE_DEBUG_DIRECTORY pSourceDebugDir = MakePtr(PIMAGE_DEBUG_DIRECTORY, sourceFileData, SourceDebugDirOffset);
		if (!CheckDebugDirectory(pSourceDebugDir, SourceDebugDirSize))
		{
			ODSDisplayError(L" Debug source directory is not valid.");
			fail = true;
			break;
		}
		// Check parameters
		if (!CheckDebugDirectory(pSourceDebugDir, SourceDebugDirSize))
		{
			ODSDisplayError(L" Debug source directory is not valid.");
			fail = true;
			break;
		}
		LPBYTE pSourceDebugInfo = (LPBYTE)sourceFileData + pSourceDebugDir->PointerToRawData;
		DWORD SourceCvSignature = *(DWORD*)pSourceDebugInfo;

		char* SourcePdbFileName;

		if (SourceCvSignature == CV_SIGNATURE_NB10)
		{
			// NB10 signature indicates format PDB 2.00
			CV_INFO_PDB20* pCvInfo = (CV_INFO_PDB20*)pSourceDebugInfo;

			if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB20)))
				return 0;
			if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
				return 0;

			//Overwrite the entire string with zeroes:
			strcpy(SourcePdbFileName, (char*)(pCvInfo->PdbFileName));
		}
		else if (SourceCvSignature == CV_SIGNATURE_RSDS)
		{
			// RSDS signature indicates format PDB 7.00
			CV_INFO_PDB70* pCvInfo = (CV_INFO_PDB70*)pSourceDebugInfo;

			if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB70)))
				return 0;
			if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
				return 0;

			//Overwrite the entire string with zeroes:
			strcpy(SourcePdbFileName, (char*)(pCvInfo->PdbFileName));
		}

		// Sanitize information in every entry in the debug directory:
		if (CleanDebugDirectoryEntries((LPBYTE)lpTargetFileMem, pTargetDebugDir, TargetDebugDirSize, SourcePdbFileName) == 0) {
			ODSDisplayInformation(L"[*] Failed to overwrite with a name now going to zero out the information");
			CleanDebugDirectoryEntries((LPBYTE)lpTargetFileMem, pTargetDebugDir, TargetDebugDirSize);
		}

		if (!CheckSumMappedFile(lpTargetFileMem, ulTargetFileSize, &dwCurrentChecksum, &dwNewChecksum))
		{
			ODSDisplayError(L"Cannot recalculate checksum for mapped target file.");
			_ASSERT(0);
		}
		pTargetNtHeaders->OptionalHeader.CheckSum = dwNewChecksum;


	} while (0); //do-while(0) with a "break" just a way to avoid using "goto"

				 // Cleanup:
	if (lpTargetFileMem != 0)
	{
		//Write out the memory-mapped file's buffer back to its file:
		if (FlushViewOfFile(lpTargetFileMem, 0) == 0)
		{
			ODSDisplayError(L"Cannot write target memory-mapped file back to disk.");
			_ASSERT(0);
		}

		if (!UnmapViewOfFile(lpTargetFileMem))
		{
			ODSDisplayError(L" Cannot unmap the target file.");
			_ASSERT(0);
		}
	}

	if (hTargetFileMap != NULL)
	{
		if (!CloseHandle(hTargetFileMap))
		{
			ODSDisplayError(L" Cannot close the target file mapping object");
			_ASSERT(0);
		}
	}

	if ((hTargetFile != NULL) && (hTargetFile != INVALID_HANDLE_VALUE))
	{
		if (!CloseHandle(hTargetFile))
		{
			ODSDisplayError(L" Cannot close the target file.");
			_ASSERT(0);
		}
	}
	
	if (lpSourceFileMem != 0)
	{
		//Write out the memory-mapped file's buffer back to its file:
		if (FlushViewOfFile(lpSourceFileMem, 0) == 0)
		{
			ODSDisplayError(L"Cannot write source memory-mapped file back to disk.");
			_ASSERT(0);
		}

		if (!UnmapViewOfFile(lpSourceFileMem))
		{
			ODSDisplayError(L"Cannot unmap the source file.");
			_ASSERT(0);
		}
	}

	if (hSourceFileMap != NULL)
	{
		if (!CloseHandle(hSourceFileMap))
		{
			ODSDisplayError(L"Cannot close the file source mapping object");
			_ASSERT(0);
		}
	}

	if ((hSourceFile != NULL) && (hSourceFile != INVALID_HANDLE_VALUE))
	{
		if (!CloseHandle(hSourceFile))
		{
			ODSDisplayError(L"Cannot close the source file.");
			_ASSERT(0);
		}
	}

	if (fail) {
		pdbPathClear(FileName);
	}
	// Complete
	ODSDisplayInformation(L"[+] Successfully cleared PDB path.");
	return 0;
}

//This function will simply clear the PDB directory path in the target PE.
int pdbPathClear(LPWSTR FileName)
{
	// Process the file
	HANDLE hFile = NULL;
	HANDLE hFileMap = NULL;
	LPVOID lpFileMem = 0;
	unsigned long ulFileSize = 0;
	//Recalculate the checksum for the file now:
	DWORD dwCurrentChecksum;
	DWORD dwNewChecksum;
	// Look up the debug directory:
	DWORD DebugDirRva = 0;
	DWORD DebugDirSize = 0;
	do
	{
		// Open the file and map it into memory:
		hFile = CreateFile(FileName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if ((hFile == INVALID_HANDLE_VALUE) || (hFile == NULL))
		{
			ODSDisplayError(L"Error: Cannot open the file.");
			break;
		}
		ulFileSize = GetFileSize(hFile, NULL);

		hFileMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL);
		if (hFileMap == NULL)
		{
			ODSDisplayError(L"Error: Cannot open the file mapping object");
			break;
		}

		lpFileMem = MapViewOfFile(hFileMap, FILE_MAP_WRITE, 0, 0, 0);
		if (lpFileMem == 0)
		{
			ODSDisplayError(L"Error: Cannot map the file");
			break;
		}
		// Is it a valid PE executable?
		PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)lpFileMem;
		if (!CheckDosHeader(pDosHeader))
		{
			ODSDisplayError(L"Error: File is not a PE executable.");
			break;
		}

		PIMAGE_NT_HEADERS pNtHeaders = MakePtr(PIMAGE_NT_HEADERS, pDosHeader, pDosHeader->e_lfanew);
		if (!CheckNtHeaders(pNtHeaders))
		{
			ODSDisplayError(L"Error: File is not a PE executable.");
			break;
		}

		if (!CheckSectionHeaders(pNtHeaders))
		{
			ODSDisplayError(L"Error: File is not a PE executable.");
			break;
		}


		if (!GetDebugDirectoryRVA(&pNtHeaders->OptionalHeader, DebugDirRva, DebugDirSize))
		{
			ODSDisplayError(L"Error: File is not a PE executable.");
			break;
		}

		if ((DebugDirRva == 0) || (DebugDirSize == 0))
		{
			ODSDisplayError(L"Debug directory not found.");
			break;
		}

		DWORD DebugDirOffset = 0;
		if (!GetFileOffsetFromRVA(pNtHeaders, DebugDirRva, DebugDirOffset))
		{
			ODSDisplayError(L"Debug directory not found.");
			break;
		}

		PIMAGE_DEBUG_DIRECTORY pDebugDir = MakePtr(PIMAGE_DEBUG_DIRECTORY, lpFileMem, DebugDirOffset);
		if (!CheckDebugDirectory(pDebugDir, DebugDirSize))
		{
			ODSDisplayError(L"Error: Debug directory is not valid.");
			break;
		}

		// Sanitize information in every entry in the debug directory:
		CleanDebugDirectoryEntries((LPBYTE)lpFileMem, pDebugDir, DebugDirSize);

		if (!CheckSumMappedFile(lpFileMem, ulFileSize, &dwCurrentChecksum, &dwNewChecksum))
			{
				ODSDisplayError(L"Error: Cannot recalculate checksum for mapped file.");
				_ASSERT(0);
			}
		pNtHeaders->OptionalHeader.CheckSum = dwNewChecksum;


	} while (0); //do-while(0) with a "break" just a way to avoid using "goto"

				 // Cleanup:
	if (lpFileMem != 0)
	{
		//Write out the memory-mapped file's buffer back to its file:
		if (FlushViewOfFile(lpFileMem, 0) == 0)
		{
			ODSDisplayError(L"Error: Cannot write memory-mapped file back to disk.");
			return 0;
		}

		if (!UnmapViewOfFile(lpFileMem))
		{
			ODSDisplayError(L"Error: Cannot unmap the file.");
			return 0;
		}
	}

	if (hFileMap != NULL)
	{
		if (!CloseHandle(hFileMap))
		{
			ODSDisplayError(L"Error: Cannot close the file mapping object");
			return 0;
		}
	}

	if ((hFile != NULL) && (hFile != INVALID_HANDLE_VALUE))
	{
		if (!CloseHandle(hFile))
		{
			ODSDisplayError(L"Error: Cannot close the file.");
			return 0;
		}
	}

	// Complete
	ODSDisplayInformation(L"[+] Successfully cleared PDB path.");
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Check IMAGE_DOS_HEADER and determine whether the file is a PE executable
// (according to the header contents)
//
// Return value: "true" if the header is valid and the file is a PE executable,
// "false" otherwise
//
bool CheckDosHeader(PIMAGE_DOS_HEADER pDosHeader)
{
	// Check whether the header is valid and belongs to a PE executable
	if (pDosHeader == 0)
	{
		return false;
	}

	if (IsBadReadPtr(pDosHeader, sizeof(IMAGE_DOS_HEADER)))
	{
		// Invalid header
		return false;
	}
	if (pDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
	{
		// Not a PE executable
		return false;
	}
	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Check IMAGE_NT_HEADERS and determine whether the file is a PE executable
// (according to the headers' contents)
//
// Return value: "true" if the headers are valid and the file is a PE executable,
// "false" otherwise
//
bool CheckNtHeaders(PIMAGE_NT_HEADERS pNtHeaders)
{
	// Check the signature
	if (pNtHeaders == 0)
	{
		return false;
	}
	if (IsBadReadPtr(pNtHeaders, sizeof(pNtHeaders->Signature)))
	{
		// Invalid header
		return false;
	}
	if (pNtHeaders->Signature != IMAGE_NT_SIGNATURE)
	{
		// Not a PE executable
		return false;
	}
	// Check the file header
	if (IsBadReadPtr(&pNtHeaders->FileHeader, sizeof(IMAGE_FILE_HEADER)))
	{
		// Invalid header
		return false;
	}
	if (IsBadReadPtr(&pNtHeaders->OptionalHeader, pNtHeaders->FileHeader.SizeOfOptionalHeader))
	{
		// Invalid size of the optional header
		return false;
	}

	// Determine the format of the header
	// If true, PE32+, otherwise PE32
	bool bPE32Plus = false;
	if (!IsPE32Plus(&pNtHeaders->OptionalHeader, bPE32Plus))
	{
		// Probably invalid IMAGE_OPTIONAL_HEADER.Magic
		return false;
	}

	// Complete
	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Lookup the section headers and check whether they are valid
//
// Return value: "true" if the headers are valid, "false" otherwise
//
bool CheckSectionHeaders(PIMAGE_NT_HEADERS pNtHeaders)
{
	if (pNtHeaders == 0)
	{
		return false;
	}

	PIMAGE_SECTION_HEADER pSectionHeaders = IMAGE_FIRST_SECTION(pNtHeaders);
	if (IsBadReadPtr(pSectionHeaders, pNtHeaders->FileHeader.NumberOfSections * sizeof(IMAGE_SECTION_HEADER)))
	{
		// Invalid header
		return false;
	}
	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Checks whether the debug directory is valid
//
// Return value: "true" if the debug directory is valid, "false" if it  is not
//
bool CheckDebugDirectory(PIMAGE_DEBUG_DIRECTORY pDebugDir, DWORD DebugDirSize)
{
	if ((pDebugDir == 0) || (DebugDirSize == 0))
	{
		return false;
	}

	if (IsBadReadPtr(pDebugDir, DebugDirSize))
	{
		// Invalid debug directory
		return false;
	}

	if (DebugDirSize < sizeof(IMAGE_DEBUG_DIRECTORY))
	{
		// Invalid size of the debug directory
		return false;
	}

	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Check whether the specified IMAGE_OPTIONAL_HEADER belongs to
// a PE32 or PE32+ file format
//
// Return value: "true" if succeeded (bPE32Plus contains "true" if the file
// format is PE32+, and "false" if the file format is PE32),
// "false" if failed
//
bool IsPE32Plus(PIMAGE_OPTIONAL_HEADER pOptionalHeader, bool& bPE32Plus)
{
	// Note: The function does not check the header for validity.
	// It assumes that the caller has performed all the necessary checks.
	// IMAGE_OPTIONAL_HEADER.Magic field contains the value that allows
	// to distinguish between PE32 and PE32+ formats 
	if (pOptionalHeader->Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC)
	{
		// PE32
		bPE32Plus = false;
	}
	else if (pOptionalHeader->Magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC)
	{
		// PE32+
		bPE32Plus = true;
	}
	else
	{
		// Unknown value -> Report an error
		bPE32Plus = false;
		return false;
	}

	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Returns (in [out] parameters) the RVA and size of the debug directory,
// using the information in
// IMAGE_OPTIONAL_HEADER.DebugDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG]
//
// Return value: "true" if succeeded, "false" if failed
//
bool GetDebugDirectoryRVA(PIMAGE_OPTIONAL_HEADER pOptionalHeader, DWORD& DebugDirRva, DWORD& DebugDirSize)
{
	// Check parameters
	if (pOptionalHeader == 0)
	{
		return false;
	}

	// Determine the format of the PE executable
	bool bPE32Plus = false;
	if (!IsPE32Plus(pOptionalHeader, bPE32Plus))
	{
		// Probably invalid IMAGE_OPTIONAL_HEADER.Magic
		return false;
	}

	// Obtain the debug directory RVA and size
	if (bPE32Plus)
	{
		PIMAGE_OPTIONAL_HEADER64 pOptionalHeader64 = (PIMAGE_OPTIONAL_HEADER64)pOptionalHeader;
		DebugDirRva = pOptionalHeader64->DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].VirtualAddress;
		DebugDirSize = pOptionalHeader64->DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].Size;
	}
	else
	{
		PIMAGE_OPTIONAL_HEADER32 pOptionalHeader32 = (PIMAGE_OPTIONAL_HEADER32)pOptionalHeader;
		DebugDirRva = pOptionalHeader32->DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].VirtualAddress;
		DebugDirSize = pOptionalHeader32->DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].Size;
	}

	if ((DebugDirRva == 0) && (DebugDirSize == 0))
	{
		// No debug directory in the executable -> no debug information
		return true;
	}
	else if ((DebugDirRva == 0) || (DebugDirSize == 0))
	{
		// Inconsistent data in the data directory
		return false;
	}

	// Complete
	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// The function walks through the section headers, finds out the section
// the given RVA belongs to, and uses the section header to determine
// the file offset that corresponds to the given RVA
//
// Return value: "true" if succeeded, "false" if failed
//
bool GetFileOffsetFromRVA(PIMAGE_NT_HEADERS pNtHeaders, DWORD Rva, DWORD& FileOffset)
{
	// Check parameters
	if (pNtHeaders == 0)
	{
		return false;
	}

	// Look up the section the RVA belongs to:
	bool bFound = false;

	PIMAGE_SECTION_HEADER pSectionHeader = IMAGE_FIRST_SECTION(pNtHeaders);
	for (int i = 0; i < pNtHeaders->FileHeader.NumberOfSections; i++, pSectionHeader++)
	{
		DWORD SectionSize = pSectionHeader->Misc.VirtualSize;

		if (SectionSize == 0) // compensate for Watcom linker strangeness, according to Matt Pietrek
			pSectionHeader->SizeOfRawData;
		if ((Rva >= pSectionHeader->VirtualAddress) && (Rva < pSectionHeader->VirtualAddress + SectionSize))
		{
			// Yes, the RVA belongs to this section
			bFound = true;
			break;
		}
	}

	if (!bFound)
	{
		// Section not found
		return false;
	}

	// Look up the file offset using the section header
	INT Diff = (INT)(pSectionHeader->VirtualAddress - pSectionHeader->PointerToRawData);

	FileOffset = Rva - Diff;
	// Complete
	return true;
}


///////////////////////////////////////////////////////////////////////////////
//
// Walk through each entry in the debug directory and clean out the PDB
// string info it may contain.
//
int CleanDebugDirectoryEntries(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, DWORD TargetDebugDirSize, char* SourcePdbFileName)
{
	int success;
	// Check parameters
	if (!CheckDebugDirectory(pTargetDebugDir, TargetDebugDirSize))
	{
		return 0;
	}

	if (pTargetImageBase == 0)
	{
		return 0;
	}

	// Determine the number of entries in the debug directory
	int NumEntries = TargetDebugDirSize / sizeof(IMAGE_DEBUG_DIRECTORY);

	if (NumEntries == 0)
	{
		return 0;
	}

	// Find information about every entry
	for (int i = 1; i <= NumEntries; i++, pTargetDebugDir++)
	{
		success = CleanDebugDirectoryEntry(pTargetImageBase, pTargetDebugDir, SourcePdbFileName);
	}
	if (success)
		return 1;
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Walk through each entry in the debug directory and clean out the PDB
// string info it may contain.
//
int CleanDebugDirectoryEntries(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, DWORD TargetDebugDirSize)
{
	int success;
	// Check parameters
	if (!CheckDebugDirectory(pTargetDebugDir, TargetDebugDirSize))
	{
		return 0;
	}

	if (pTargetImageBase == 0)
	{
		return 0;
	}

	// Determine the number of entries in the debug directory
	int NumEntries = TargetDebugDirSize / sizeof(IMAGE_DEBUG_DIRECTORY);

	if (NumEntries == 0)
	{
		return 0;
	}

	// Find information about every entry
	for (int i = 1; i <= NumEntries; i++, pTargetDebugDir++)
	{
		success = CleanDebugDirectoryEntry(pTargetImageBase, pTargetDebugDir);
	}
	if (success)
		return 1;
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Find the PDB string info in the debug directory entry and delete it.
//
int CleanDebugDirectoryEntry(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir, char* SourcePdbFileName)
{
	int success;
	// Check parameters:
	if (pTargetDebugDir == 0)
	{
		return 0;
	}

	if (pTargetImageBase == 0)
	{
		return 0;
	}
	//get the target debug info
	LPBYTE pTargetDebugInfo = pTargetImageBase + pTargetDebugDir->PointerToRawData;
	if (pTargetDebugDir->Type == IMAGE_DEBUG_TYPE_CODEVIEW )
	{
		success = CleanCodeViewDebugInfo(pTargetDebugInfo, pTargetDebugDir->SizeOfData, SourcePdbFileName);
	}

	if (success)
		return 1;
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Find the PDB string info in the debug directory entry and delete it.
//
int CleanDebugDirectoryEntry(LPBYTE pTargetImageBase, PIMAGE_DEBUG_DIRECTORY pTargetDebugDir)
{
	int success;
	// Check parameters:
	if (pTargetDebugDir == 0)
	{
		return 0;
	}

	if (pTargetImageBase == 0)
	{
		return 0;
	}

	//get the target debug info
	LPBYTE pTargetDebugInfo = pTargetImageBase + pTargetDebugDir->PointerToRawData;

	if (pTargetDebugDir->Type == IMAGE_DEBUG_TYPE_CODEVIEW)
	{
		success = CleanCodeViewDebugInfo(pTargetDebugInfo, pTargetDebugDir->SizeOfData);
	}

	if (success)
		return 1;
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Find the PDB string info in the CodeView debug information block and  delete
// it.
//
int CleanCodeViewDebugInfo(LPBYTE pTargetDebugInfo, DWORD TargetDebugInfoSize, char* SourcePdbFileName)
{
	// Check parameters
	if ((pTargetDebugInfo == 0) || (TargetDebugInfoSize == 0))
		return 0;

	if (IsBadReadPtr(pTargetDebugInfo, TargetDebugInfoSize))
		return 0;

	if (TargetDebugInfoSize < sizeof(DWORD)) // size of the signature
		return 0;


	DWORD TargetCvSignature = *(DWORD*)pTargetDebugInfo;

	char* TargetPdbFileName;

	// Determine the format of the information:
	if (TargetCvSignature == CV_SIGNATURE_NB10)
	{
		// NB10 signature indicates format PDB 2.00
		CV_INFO_PDB20* pCvInfo = (CV_INFO_PDB20*)pTargetDebugInfo;

		if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB20)))
			return 0;
		if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
			return 0;

		//Overwrite the entire string with zeroes:
		TargetPdbFileName = (char*)(pCvInfo->PdbFileName);

		int iLength = strlen(TargetPdbFileName);
		int jLength = strlen(SourcePdbFileName);
		if (jLength <= iLength) {
			int j = 0;
			for (int i = 0; i < iLength; i++)
			{
				if (j < jLength) {
					pCvInfo->PdbFileName[i] = SourcePdbFileName[i];
				}
				else {
					if (i == jLength) {
						pCvInfo->PdbFileName[i] = '\0';
					}
					pCvInfo->PdbFileName[i] = 0x00;
				}
				j++;
			}
		}
		else {
			for (int i = 0; i < iLength; i++)
			{
				pCvInfo->PdbFileName[i] = 0x00;
			}
		}
	}
	else if (TargetCvSignature == CV_SIGNATURE_RSDS)
	{
		// RSDS signature indicates format PDB 7.00
		CV_INFO_PDB70* pCvInfo = (CV_INFO_PDB70*)pTargetDebugInfo;

		if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB70)))
			return 0;
		if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
			return 0;

		//Overwrite the entire string with zeroes:
		TargetPdbFileName = (char*)(pCvInfo->PdbFileName);
		int iLength = strlen(TargetPdbFileName);
		int jLength = strlen(SourcePdbFileName);
		if (jLength <= iLength) {
			int j = 0;
			for (int i = 0; i < iLength; i++)
			{
				if (j < jLength) {
					pCvInfo->PdbFileName[i] = SourcePdbFileName[i];
				}
				else {
					if (i == jLength) {
						pCvInfo->PdbFileName[i] = '\0';
					}
					pCvInfo->PdbFileName[i] = 0x00;
				}
				j++;
			}
		}
		else {
			for (int i = 0; i < iLength; i++)
			{
				pCvInfo->PdbFileName[i] = 0x00;
			}
		}
	}
	return 1;

}

///////////////////////////////////////////////////////////////////////////////
//
// Find the PDB string info in the CodeView debug information block and  delete
// it.
//
int CleanCodeViewDebugInfo(LPBYTE pTargetDebugInfo, DWORD TargetDebugInfoSize)
{
	// Check parameters
	if ((pTargetDebugInfo == 0) || (TargetDebugInfoSize == 0))
		return 0;

	if (IsBadReadPtr(pTargetDebugInfo, TargetDebugInfoSize))
		return 0;

	if (TargetDebugInfoSize < sizeof(DWORD)) // size of the signature
		return 0;

	DWORD TargetCvSignature = *(DWORD*)pTargetDebugInfo;

	char* TargetPdbFileName;

	// Determine the format of the information:
	if (TargetCvSignature == CV_SIGNATURE_NB10)
	{
		// NB10 signature indicates format PDB 2.00
		CV_INFO_PDB20* pCvInfo = (CV_INFO_PDB20*)pTargetDebugInfo;

		if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB20)))
			return 0;
		if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
			return 0;

		//Overwrite the entire string with zeroes:
		TargetPdbFileName = (char*)(pCvInfo->PdbFileName);

		int iLength = strlen(TargetPdbFileName);
		for (int i = 0; i < iLength; i++)
		{

			pCvInfo->PdbFileName[i] = 0x00;
		}

	}
	else if (TargetCvSignature == CV_SIGNATURE_RSDS)
	{
		// RSDS signature indicates format PDB 7.00
		CV_INFO_PDB70* pCvInfo = (CV_INFO_PDB70*)pTargetDebugInfo;

		if (IsBadReadPtr(pCvInfo, sizeof(CV_INFO_PDB70)))
			return 0;
		if (IsBadStringPtrA((CHAR*)pCvInfo->PdbFileName, UINT_MAX))
			return 0;

		//Overwrite the entire string with zeroes:
		TargetPdbFileName = (char*)(pCvInfo->PdbFileName);
		int iLength = strlen(TargetPdbFileName);
		for (int i = 0; i < iLength; i++)
		{
			pCvInfo->PdbFileName[i] = 0x00;
		}
	}
	return 1;

}

