#include "WMICovertStorage.h"
#include "CoreUtilities.h"

//TODO: Change this out to a struct that is passed when the WMI storage is intialized


HANDLE hMutex;

//Takes a struct as input to operate on
//Return type is DWORD to indicate success or failure
DWORD SetupWMILogging(WMILogInstance* liWMILogger) {
    HRESULT hres;

	hMutex = CreateMutex(NULL,  FALSE, liWMILogger->LOG_MUTEX);;
	if(hMutex == NULL) {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to create mutex"));
		return -1;
	}

    // Step 1: --------------------------------------------------
    // Initialize COM. ------------------------------------------
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if (FAILED(hres))
    {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to intialize COM Object"));
        return -1;                 
    }

    // Step 2: --------------------------------------------------
    // Set general COM security levels --------------------------

    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM negotiates service
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );


    if (FAILED(hres))
    {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to intialize COM Security"));
        CoUninitialize();
        return -1;                      // Program has failed.
    }

    // Step 3: ---------------------------------------------------
    // Obtain the initial locator to WMI -------------------------

    hres = CoCreateInstance(
        CLSID_WbemLocator,
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *)&liWMILogger->pLoc);
 
    if (FAILED(hres))
    {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to create instance of COM Object"));
        CoUninitialize();
        return -1;                 // Program has failed.
    }

    // Step 4: ---------------------------------------------------
    // Connect to WMI through the IWbemLocator::ConnectServer method

    // Connect to the local root\cimv2 namespace
    // and obtain pointer pSvc to make IWbemServices calls.
    hres = liWMILogger->pLoc->ConnectServer(
        _bstr_t(L"ROOT\\CIMV2"), 
        NULL,
        NULL, 
        0, 
        NULL, 
        0, 
        0, 
		&liWMILogger->pSvc
    );

    if (FAILED(hres))
    {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to connect to WMI Server"));
		liWMILogger->pLoc->Release();
        CoUninitialize();
        return -1;                // Program has failed.
    }

    // Step 5: --------------------------------------------------
    // Set security levels for the proxy ------------------------

    hres = CoSetProxyBlanket(
		liWMILogger->pSvc,            // Indicates the proxy to set
        RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx 
        RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx 
        NULL,                        // Server principal name 
        RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
        RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
        NULL,                        // client identity
        EOAC_NONE                    // proxy capabilities 
    );

    if (FAILED(hres))
    {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to Set Proxy Blanket"));
		liWMILogger->pSvc->Release();
		liWMILogger->pLoc->Release();
        CoUninitialize();
        return -1;               // Program has failed.
    }

    return 0;
}

void CleanupWMILogging(WMILogInstance* liWMILogger) {
	liWMILogger->pLoc->Release();
	liWMILogger->pSvc->Release();
    CoUninitialize();
}

void currentTimestamp(WMILogInstance* liWMILogger, wchar_t* result) {
	SYSTEMTIME st;
	GetSystemTime(&st);

	swprintf(result, 84, L"%04d/%02d/%02d %02d:%02d:%02d %03d-%03d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, liWMILogger->message_num++);

	if(liWMILogger->message_num > 999) {
		liWMILogger->message_num = 0;
	}

	return;
}

int WriteWMILog (WMILogInstance* liWMILogger, char* message) {
	int len = strlen(message);
	if(len < 1) {
		ODSDisplayError(TEXT("WMI Covert Storage: Invalid char message size"));
		return -1;
	}

	char* null_term_message = (char*)malloc(len+1);
	memset(null_term_message,0,len+1);
	strncpy(null_term_message, message, len);

	LPWSTR wMessage = CharToWChar(null_term_message);
	WriteWMILog(liWMILogger, wMessage);

	free(null_term_message);
}

int WriteWMILog (WMILogInstance* liWMILogger, LPWSTR message)
{
	int len = wcslen(message);
	WaitForSingleObject(hMutex, INFINITE);
	IWbemClassObject *pNewInstance = 0;
    IWbemClassObject *pCOMClass = 0;
    IWbemContext *pCtx = 0;
    IWbemCallResult *pResult = 0;

	if(len < 1) {
		ODSDisplayError(TEXT("WMI Covert Storage: Invalid wchar message size"));
		ReleaseMutex(hMutex);
		return -1;
	}

    // Get the class definition.
    BSTR PathToClass = SysAllocString(liWMILogger->WMI_CLASS_NAME);
    HRESULT hRes = liWMILogger->pSvc->GetObject(PathToClass, 0, pCtx,
                 &pCOMClass, &pResult);
    SysFreeString(PathToClass);

	if(hRes != WBEM_S_NO_ERROR) {
		CreateClass(liWMILogger);
		PathToClass = SysAllocString(liWMILogger->WMI_CLASS_NAME);
		pCtx = 0;
		pCOMClass = 0;
		pResult = 0;
		hRes = liWMILogger->pSvc->GetObject(PathToClass, 0, pCtx,
                 &pCOMClass, &pResult);
		SysFreeString(PathToClass);
	}
	
	if (hRes != WBEM_S_NO_ERROR) {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to get class definition"));
		ReleaseMutex(hMutex);
		return -1;
	}

    // Create a new instance.
    pCOMClass->SpawnInstance(0, &pNewInstance);
    pCOMClass->Release();  // Don't need the class any more

    VARIANT v;
    VariantInit(&v);

    // Set the Index property (the key).
	wchar_t timeBuf[100];
	currentTimestamp(liWMILogger, timeBuf);
    V_VT(&v) = VT_BSTR;
    V_BSTR(&v) = SysAllocString(timeBuf);

    BSTR KeyProp = SysAllocString(L"Index");
    hRes = pNewInstance->Put(KeyProp, 0, &v, 0);
    SysFreeString(KeyProp);
    VariantClear(&v);

	if(hRes != WBEM_S_NO_ERROR) {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to set the index property"));
		ReleaseMutex(hMutex);
		return -1;
	}

    // Set the IntVal property.
    V_VT(&v) = VT_BSTR;
	V_BSTR(&v) = SysAllocString(message);
    
    BSTR Prop = SysAllocString(L"Message");
    hRes = pNewInstance->Put(Prop, 0, &v, 0);
    SysFreeString(Prop);
    VariantClear(&v);

	if(hRes != WBEM_S_NO_ERROR) {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to set IntVal"));
		ReleaseMutex(hMutex);
		return -1;
	}
    
    // Other properties acquire the 'default' value specified
    // in the class definition unless otherwise modified here.

    // Write the instance to WMI. 
    hRes = liWMILogger->pSvc->PutInstance(pNewInstance, 0, pCtx, &pResult);

	if(hRes != WBEM_S_NO_ERROR) {
		ODSDisplayError(TEXT("WMI Covert Storage: Failed to write instance to WMI"));
		ReleaseMutex(hMutex);
		return -1;
	}

    pNewInstance->Release();
	ReleaseMutex(hMutex);
	return 0;
}

int CreateClass(WMILogInstance* liWMILogger)
{
  IWbemClassObject *pNewClass = 0;
  IWbemContext *pCtx = 0;
  IWbemCallResult *pResult = 0;

  // Get a class definition. 
  // ============================
  HRESULT hRes = liWMILogger->pSvc->GetObject(0, 0, pCtx, &pNewClass, &pResult);

  if(hRes != WBEM_S_NO_ERROR) {
	  ODSDisplayError(TEXT("WMI Covert Storage: Failed to get class definition"));
	  return -1;
  }

  VARIANT v;
  VariantInit(&v);

  // Create the class name.
  // ============================
  V_VT(&v) = VT_BSTR;
  V_BSTR(&v) = SysAllocString(liWMILogger->WMI_CLASS_NAME);
  BSTR Class = SysAllocString(L"__CLASS");
  hRes = pNewClass->Put(Class, 0, &v, 0);
  SysFreeString(Class);
  VariantClear(&v);

  if(hRes != WBEM_S_NO_ERROR) {
	  return -1;
  }

  // Create the key property. 
  // ============================
  BSTR KeyProp = SysAllocString(L"Index");
  hRes = pNewClass->Put(KeyProp, 0, NULL, CIM_STRING);

  if(hRes != WBEM_S_NO_ERROR) {
	  ODSDisplayError(TEXT("WMI Covert Storage: Failed to create key property"));
	  return -1;
  }

  // Attach Key qualifier to mark the "Index" property as the key.
  // ============================
  IWbemQualifierSet *pQual = 0;
  hRes = pNewClass->GetPropertyQualifierSet(KeyProp, &pQual);
  SysFreeString(KeyProp);

  V_VT(&v) = VT_BOOL;
  V_BOOL(&v) = VARIANT_TRUE;
  BSTR Key = SysAllocString(L"Key");

  hRes = pQual->Put(Key, &v, 0);   // Flavors not required for Key 
  SysFreeString(Key);

  if(hRes != WBEM_S_NO_ERROR) {
	  ODSDisplayError(TEXT("WMI Covert Storage: Failed to attach key qualifier"));
	  return -1;
  }

  // No longer need the qualifier set for "Index"
  pQual->Release();     
  VariantClear(&v);

  // Create other properties.
  // ============================
  V_VT(&v) = VT_BSTR;
  V_BSTR(&v) = SysAllocString(L"<default>");
  BSTR OtherProp = SysAllocString(L"Message");
  hRes = pNewClass->Put(OtherProp, 0, &v, CIM_STRING);
  SysFreeString(OtherProp);
  VariantClear(&v);

  if(hRes != WBEM_S_NO_ERROR) {
	  ODSDisplayError(TEXT("WMI Covert Storage: Failed to create other properties"));
	  return -1;
  }

  /* OtherProp = SysAllocString(L"IntVal");
  pNewClass->Put(OtherProp, 0, NULL, CIM_SINT32); // NULL is default
  SysFreeString(OtherProp);*/
  
  // Register the class with WMI
  // ============================
  hRes = liWMILogger->pSvc->PutClass(pNewClass, 0, pCtx, &pResult);
  pNewClass->Release();

  if(hRes != WBEM_S_NO_ERROR) {
	  ODSDisplayError(TEXT("WMI Covert Storage: Failed to register class"));
	  return -1;
  }

  return 0;
}