#pragma once


#include "CoreUtilities.h"
//#include <strsafe.h> 
#include <stdio.h>
#include <Windows.h>
//#include <direct.h>
#include <Imagehlp.h>
#include "Shlwapi.h"
#include <tchar.h>
//#include <crtdbg.h>
//#include <limits.h>
#include <string>
#include <algorithm>

////////////////////////////////////////////////////////////////
//Defines
///////////////////////////////////////////////////////////////
#define OBJ_EXCLUSIVE           0x00000020L
#define OBJ_KERNEL_HANDLE       0x00000200L
#define FILE_NON_DIRECTORY_FILE 0x00000040
#define PE_LOCATION_POINTER_OFFSET 0x3c

////////////////////////////////////////////////////////////////
//Helpful memory management defines
///////////////////////////////////////////////////////////////
#define memory_allocate( size ) \
	HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T) size )

#define memory_free( buffer ) \
	HeapFree( GetProcessHeap(), NULL, (LPVOID) buffer )

#define byte_stream_copy_to_uint16_little_endian( byte_stream, value ) \
	( value )   = ( byte_stream )[ 1 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 0 ];

#define byte_stream_copy_to_uint32_little_endian( byte_stream, value ) \
	( value )   = ( byte_stream )[ 3 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 2 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 1 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 0 ];

#define byte_stream_copy_to_uint64_little_endian( byte_stream, value ) \
	( value )   = ( byte_stream )[ 7 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 6 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 5 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 4 ]; \
	( value ) <<= 8; \
	( value )   = ( byte_stream )[ 3 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 2 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 1 ]; \
	( value ) <<= 8; \
	( value )  |= ( byte_stream )[ 0 ];

////////////////////////////////////////////////////////////////
//Type Defs
///////////////////////////////////////////////////////////////
typedef LONG NTSTATUS;

typedef struct _IO_STATUS_BLOCK {
	union {
		NTSTATUS Status;
		PVOID Pointer;
	};
	ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

typedef enum _FILE_INFORMATION_CLASS {
	FileBasicInformation = 4,
	FileStandardInformation = 5,
	FilePositionInformation = 14,
	FileEndOfFileInformation = 20,
} FILE_INFORMATION_CLASS, *PFILE_INFORMATION_CLASS;

typedef struct _FILE_BASIC_INFORMATION {
	LARGE_INTEGER CreationTime;							// Created             
	LARGE_INTEGER LastAccessTime;                       // Accessed    
	LARGE_INTEGER LastWriteTime;                        // Modifed
	LARGE_INTEGER ChangeTime;                           // Entry Modified
	ULONG FileAttributes;
} FILE_BASIC_INFORMATION, *PFILE_BASIC_INFORMATION;

typedef NTSTATUS(WINAPI *pNtQueryInformationFile)(HANDLE, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS);
typedef NTSTATUS(WINAPI *pNtSetInformationFile)(HANDLE, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS);



////////////////////////////////////////////////////////////////
//TimeStomping functions
///////////////////////////////////////////////////////////////
HANDLE RetrieveFileBasicInformation(TCHAR* filename, FILE_BASIC_INFORMATION *fbi);
DWORD SetFileMACE(HANDLE file, FILE_BASIC_INFORMATION fbi);
DWORD ParseDateTimeInput(char *inputstring, SYSTEMTIME *systemtime);
DWORD ConvertLocalTimeToLargeInteger(SYSTEMTIME localsystemtime, LARGE_INTEGER *largeinteger);
DWORD ConvertLargeIntegerToLocalTime(SYSTEMTIME *localsystemtime, LARGE_INTEGER largeinteger);
DWORD InputHandler(int argc, char **argv);
DWORD TimeStomp(TCHAR* targetFile, TCHAR* sourceFile);
DWORD TimeStompPath(LPWSTR targetFile, TCHAR* sourceFile, int levels);
int ModifyFileCompileTime(LPWSTR filePath, LPWSTR fileToMimic);
void PrintSystemTime(SYSTEMTIME systime);
void Usage();



////////////////////////////////////////////////////////////////
//Path and File Creation functions
///////////////////////////////////////////////////////////////
DWORD CreatePath(LPWSTR lpDirectoryPath);
DWORD CreateStompedPath(LPWSTR lpDirectoryPath, TCHAR* tsSourceFile);
DWORD DropFiles(HMODULE hDLL, int ResourceID, LPWSTR lpDropFilePath, DWORD Attributes);
int CopyVersionInformation(LPWSTR targetPath, LPWSTR sourcePath);
LPWSTR pathStripper(LPWSTR oldPath);

////////////////////////////////////////////////////////////////
//Permision modification functions
///////////////////////////////////////////////////////////////
HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable);

////////////////////////////////////////////////////////////////
//PDB Moidification functions
///////////////////////////////////////////////////////////////
int pdbPathClear(LPWSTR FileName);
int pdbPathCopy(LPWSTR FileName, LPWSTR fileToMimic);
