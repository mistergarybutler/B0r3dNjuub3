For 64bit hook dll projects use madCHook64mt.lib.
For 64bit exe projects you can use either madCHook64md.lib or madCHook64mt.lib, whichever you prefer.