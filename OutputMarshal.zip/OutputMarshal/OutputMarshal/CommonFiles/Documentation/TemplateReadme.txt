========================================================================
                       WINDOWS CAPABILITY TEMPLATE
                      Version: 0.1b / CAO: 20161004
========================================================================
This is a generated template file to the current Windows Capability Standard.
The project/files contained in this template are described below:

                            ***** PROJECTS *****

Template_StandardConsoleApp_EXE
	This is the standard console application representation of the capability.
	It is designed to be run from the disk of the target system with arguments 
	provided at the command line invocation to configure custom parameters. 
	This project contains bootstrap and argument parsing code only. All core 
	functionality is contained within the static library project.

Template_StandardDynamicLibrary_DLL
	This is the standard DLL representation of the capability. It is designed to
	be loaded using standard or modified Windows mechanisms for loading from disk
	to a specified process. This project contains bootstrap and argument parsing 
	code only. All core functionality is contained within the static library 
	project.

Template_StandardReflectiveLibrary_RDLL
	This is the standard reflective library representation of the capability. 
	It is designed to be loaded using the publically released reflective loading
	mechanism. All arguments to the capability are set using preprocessor directives
	contained within the project properties or at the top of the appropriate source
	file(s). This project contains bootstrap and argument parsing code only. All core 
	functionality is contained within the static library project.

Template_StandardStaticLibary_LIB
	This is the core functionality of the Windows Capability. All functional
	code is contained in this project and linked to by the other representations
	that are part of the capability solution

Test_DynamicLibaryLoader_EXE
	This is a testing project to support development and debugging of the standard
	dynamic library project within the VisualStudio IDE.

Test_UnitTests_EXE
	This is a testing project to support the development and validation of the 
	utility functions that are included in the standard template. It is built to
	support the construction of the Windows Capability template, so it should be 
	removed/deleted for production code.


                          ***** FILES/FOLDERS *****

$(SolutionDir)\CommonFiles\
	Contains the files that are common among the Windows capabilities that are 
	typically developed. 

$(SolutionDir)\CommonFiles\CommonLibs\
	Contains all non-standard CNO libraries that are useful for capability
	development. NOTE: Standard development libraries such as SDKs and DDKs
	are not included in this directory.

$(SolutionDir)\CommonFiles\MadCodeHook\
	Contains the header file required for the commercial 32/64-bit MadCodeHook
	API/COM hooking library. It is not included in any template project by 
	default.

$(SolutionDir)\CommonFiles\MicrosoftDetours\
	Contains the header file required for the public 32-bit Microsoft Detours
	library. It is not included in any template project by default.

$(SolutionDir)\CommonFiles\PublicReflectiveInjection\
	Contains the source and header files required for the public 32/64-bit
	reflective injection technique by Stephen Fewer. It is included in the
	StandardReflectiveLibrary template by default.

$(SolutionDir)\CommonFiles\UtilityFunctions\
	Contains the standardized utility functions that are common accross all
	typical Windows capabilities. It is included in all template projects by
	default. 