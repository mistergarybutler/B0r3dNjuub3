#pragma once
#include <windows.h>

#define MAILSLOT_SERVER
//#define MAILSLOT_CLIENT

//Functions usable by other projects
BOOL WINAPI MakeSlot(LPTSTR lpszSlotName);
BOOL WriteSlot(HANDLE hSlot, LPTSTR lpszMessage);
BOOL ReadSlot();
