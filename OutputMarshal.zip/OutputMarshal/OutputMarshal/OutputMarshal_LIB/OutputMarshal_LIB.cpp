//The core functionality of the capability is implemented in this file and associated project files

#include "stdafx.h"
#include "OutputMarshal_LIB.h"
#include "MailSlot_LIB.h"
#include "..\CommonFiles\UtilityFunctions\CoreUtilities.h"
#include "..\CommonFiles\UtilityFunctions\ProcessUtilities.h"
#include <shellapi.h> /**< Import required for parsing lpzCmdline back to arguments*/
#include <wchar.h> /**< Import required for swprintf_s call*/
#include <string> /**< Required to support processing the configuration file line by line*/
#include <sstream> /**< Required to support processing the configuration file line by line*/

/**
* @brief Extract command lines to execute from an embedded resource
*
* This function supports either single commands or a list of commands separated by a Windows newline separator
* CRLF (\r\n). Any script or other tool modifying the embedded resource should support this assumption. For 
* maximum safety, any resource sent to this function should have the last line as EOF.
*
* @param ResourceID The numerical ID of the embedded resource
*
* @return 0 on success, any other value is failure
* @warning empty lines in the configuration file will cause the parser to overrun and go into the next resources
*/
DWORD LibExtractCmdsFromResource(int ResourceID) {
	int retval = -1;

	//Find ourself in memory so we can locate the embedded resources
	HMODULE hDLL = GetCurrentModule();
	if (hDLL == NULL) {
		ODSDisplayError(TEXT("Couldn't find embedded resource"));
		retval = -1;
		goto FAILURE;
	}

	//Get the commands to execute from the resource
	LPCWSTR lpszCmdLine = GetResourceAsLPCWSTR(hDLL, ResourceID);

	//Convert the commands to a modifiable format
	int bufSize = wcslen(lpszCmdLine) + 2;
	TCHAR * buffer = (TCHAR *)halloc(bufSize * sizeof(TCHAR));
	swprintf_s(buffer, bufSize, L" %ws", lpszCmdLine);

	//Loop through all lines in the resource, breaking on each newline
	wchar_t *token;
	wchar_t separator[] = L"\r\n"; //ASSUMPTION: The configuration file uses windows line breaks. May not be valid in all cases
	token = wcstok(buffer, separator);
	while (token != NULL || wcscmp(token, L"EOF") == 0) {
		if (FAILED(LibCmdLineParser(token))) {
			//Do processing if failing on one command in the configuration is a serious condition
			//Otherwise just keep going
		}
		/* Get next token: */
		token = wcstok(NULL, separator);

		//Break if that token is a Null or EOF
		if (token == NULL || wcscmp(token, L"EOF") == 0) {
			break;
		}
			
	}

SUCCESS:
	retval = 0;
FAILURE:
	hfree((void*)buffer); //Free the buffer that held the commands

	return retval;
}

/**
* @brief Convert a lpszCmdline string into argc/argv
*
* Allow EXEs, DLLs, and RDLLs to pass in an lpszCmdline to get it converted to a format that
* the universal command parser can utilize.
*
* @param lpszCmdLine The command line to process
*
* @return 0 on success, any other value is failure
* @see https://msdn.microsoft.com/en-us/library/windiows/desktop/bb776391.aspx
*/
DWORD LibCmdLineParser(LPCWSTR lpszCmdLine) {
	int retval = -1;

	//Parse lpszCmdLine back into the individual arguments
	LPWSTR* argv;
	int argc;

	//Reflow arguments to match the way an EXE would call
	int newSize = wcslen(lpszCmdLine) + 2;
	TCHAR * buffer = (TCHAR *)halloc(newSize * sizeof(TCHAR));
	swprintf_s(buffer, newSize, L" %ws", lpszCmdLine);

	argv = CommandLineToArgvW(buffer, &argc);
	if (argv == NULL) {
		ODSDisplayError(TEXT("CommandLineToArgvW Failed"));
		retval = -1;
		goto FAILURE;
	}

	//Call the Static Library's command parser
	if (LibCommandParser(argc, argv) != 0) {
		//Display usage instructions
		ODSDisplayError(TEXT("Cmdline Parser: Failed to validate arguments."));
		retval = -1;
		goto FAILURE;
	}
	

SUCCESS:
	retval = 0;

FAILURE:
	hfree((void*)buffer); //Free the modified buffer

	return retval;
}

/**
 * @brief Universal command parser
 *
 * Take in raw argc/argv from the various stubs, parse and call the entry point
 *
 * @param argc The number of arguments received from the invoking function
 * @param argv An array of the value of the arguments received from the invoking function
 *
 * @return 0 on success, any other value is failure
 */
DWORD LibCommandParser(int argc, TCHAR* argv[]) {
	int retval = -1;

#ifdef PRINT_TO_NORMAL
	//Test block to output the exact details of the command line invocation
	ODSDisplayInformation(TEXT("***** COMMAND LINE INVOCATION *****\n"));
	ODSDisplayInformation(TEXT("[*] Number of Arguments: %d\n"), argc);
	for (int i = 0; i < argc; i++) {
		ODSDisplayInformation(TEXT("[*] Argument #%d: %s\n"), i, argv[i]);
	}
	ODSDisplayInformation(TEXT("***********************************\n"));
	//Basic argument validity parsing.
	//TODO: Add additional argument parsing functionality if required
	//TRADECRAFT: Avoid outputting any error messages in release mode, just exit silently
	int argcExpected = 2;
	if (argc != argcExpected) {
		ODSDisplayError(TEXT("Failed to validate arguments."));
		retval = -1;
		goto FAILURE;
	}
#endif

#ifdef PRINT_TO_MAILSLOT
	OutputMarshal(DEBUG_LEVEL, argc, argv);
#endif

	//Call the static library entrypoint
	LibEntryPoint(argv[1]);

SUCCESS:
	retval = 0;
FAILURE:

	return retval;
}

//This entry point should be modified to support passing arguments from whatever form
//ends up calling the function
//It should only be called directly by:
//- The Standard DLL's normal exported function
//- The Reflective DLL's preprocessor definition method
void LibEntryPoint(LPWSTR TextToEcho) {
	ODSDisplayInformation(TEXT("[*] Echoed Text: %s\n"), TextToEcho);
}

#ifdef PRINT_TO_ODS
void OutputMarshal(DWORD debug_level, int argc, TCHAR* argv[]) {
	//Define how debug_level and argv should be handled by ODSDisplayInformation()
}
#endif

#ifdef PRINT_TO_MAILSLOT
void OutputMarshal(DWORD debug_level, int argc, TCHAR* argv[]) {
#ifdef MAILSLOT_SERVER

	LPTSTR Slot = TEXT("\\\\.\\mailslot\\%s", argv[1]);

	MakeSlot(Slot);

	while (TRUE)
	{
		ReadSlot();
		Sleep(3000);
	}
#endif

#ifdef MAILSLOT_CLIENT
	LPTSTR SlotName = TEXT("\\\\.\\mailslot\\%s", argv[1]);
	HANDLE hFile;

	hFile = CreateFile(SlotName,
		GENERIC_WRITE,
		FILE_SHARE_READ,
		(LPSECURITY_ATTRIBUTES)NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		(HANDLE)NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		printf("CreateFile failed with %d.\n", GetLastError());
	}

	WriteSlot(hFile, TEXT("Message one for mailslot."));

	WriteSlot(hFile, TEXT("Message two for mailslot."));

	Sleep(5000);

	WriteSlot(hFile, TEXT("Message three for mailslot."));

	CloseHandle(hFile);
#endif
}
#endif