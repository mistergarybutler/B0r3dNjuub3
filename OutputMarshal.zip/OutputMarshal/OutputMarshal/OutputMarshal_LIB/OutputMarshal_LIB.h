#pragma once
#include <windows.h>

//Uncomment one and only one of the below defines to select Debug level
#define DEBUG_LEVEL 0
//#define DEBUG_LEVEL 1
//#define DEBUG_LEVEL 2
//#define DEBUG_LEVEL 3
//#define DEBUG_LEVEL 4
//#define DEBUG_LEVEL 5
//#define DEBUG_LEVEL 6
//#define DEBUG_LEVEL 7

//#define PRINT_TO_NORMAL
//#define PRINT_TO_ODS
#define PRINT_TO_MAILSLOT

//Functions usable by other projects
DWORD LibExtractCmdsFromResource(int ResourceID);
DWORD LibCmdLineParser(LPCWSTR lpszCmdLine);
DWORD LibCommandParser(int argc, TCHAR* argv[]); //Standardized command parser
void OutputMarshal(DWORD debug_level, int argc, TCHAR* argv[]);

//The main entry point of the static library code
//TODO: Modify this prototype to your entry point specifications
void LibEntryPoint(LPWSTR TextToEcho);